﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessDemo
{
	public struct MoveInfo
	{
		public int src, dst;
	}

	class Minimax
	{
		Hashtable[] hashtable = new Hashtable[2];

		int MAX_VALUE = 2000000000;
		int MIN_VALUE = -2000000000;

		int m_nSearchPiece, m_nMaxPly = 5;

		public void init()
		{
			hashtable[0] = new Hashtable();
			hashtable[1] = new Hashtable();
		}

		void SetSearchPiece( int nPiece )
		{
			m_nSearchPiece = nPiece;
		}

		public void GetMove( ref MoveInfo pos, ref ChessEngine brd, int nPiece )
		{
			hashtable[0] = new Hashtable();
			hashtable[1] = new Hashtable();

			SetSearchPiece(nPiece);
			ChessEngine brd2 = brd.Clone();

			DoSearch(ref pos, nPiece, 0, brd2, MIN_VALUE, MAX_VALUE);
		}

		int[] LegalMoveList( ChessEngine brd, int nPiece )
		{
			ArrayList lst = new ArrayList();
			int[] lst2 = new int[1000];

			for( int sq=0; sq<64; sq++ )
			{
				if( brd.GetColor( sq ) == nPiece )
				{
					int cnt = brd.GetLegalMoveList(sq, ref lst2);
					for( int i=0; i<cnt; i++ )
					{
						lst.Add(sq);
						lst.Add(lst2[i]);
					}
				}
			}

			int[] ret = new int[lst.Count];
			for (int i = 0; i < ret.Length; i++) ret[i] = (int)lst[i];
			return (ret);
		}

		bool DidWin( ChessEngine brd, int nPiece )
		{
			int[] moves = LegalMoveList(brd, nPiece^1);
			return( moves.Length == 0 );
		}

		char[] GetBoardData( ChessEngine brd )
		{
			char[] boarddata = new char[128];
			for (int i = 0; i < 64; i++) boarddata[i] = (char)brd.GetColor(i);
			for (int i = 0; i < 64; i++) boarddata[64 + i] = (char)brd.GetPiece(i);
			return (boarddata);
		}

		int DoSearch(ref MoveInfo pos, int nPiece, int nDepth, ChessEngine brd, int nAlpha, int nBeta)
		{
			int nValue = 0;

			if ( nDepth > 0 && hashtable[nPiece].ContainsKey(new string(GetBoardData(brd))))
			{
				return( (int)hashtable[nPiece][new string( GetBoardData(brd) )] );
			}

			// First, see if a side has won.
			if ( DidWin(brd, nPiece) )
			{
				if (nPiece == m_nSearchPiece)
				{
					return (MAX_VALUE);
				}
				return (MIN_VALUE);
			}

			// If we are at a leaf node, return the score.
			if (nDepth >= m_nMaxPly)
			{
				int nScore = brd._ScorePosition(nPiece);
				//int nScore = brd.MaterialAdvantage(nPiece);

				hashtable[nPiece].Add(new string(GetBoardData(brd)), nScore);
				return (nScore);
			}

			int[] MoveList = LegalMoveList(brd, nPiece);
			if (nDepth == 0)
			{
				pos.src = MoveList[0];
				pos.dst = MoveList[1];
			}

			// TEST
			MoveList = ReOrder(MoveList, brd);

			// Maximizer
			if( nPiece == m_nSearchPiece )
			{

				// Loop through the legal moves.
				for( int i=0; i<MoveList.Length/2; i++ )
				{
					// We need a board clone so that we can place pieces
					//   without messing up previous board positions.
					ChessEngine Temp = brd.Clone();
			
					// Place the piece from the current move in the list.
					Temp.MakeHumanMove(MoveList[i * 2], MoveList[i * 2 + 1], false);
			
					int nTempValue = nAlpha;

					// Call DoSearch() recursively.
					nValue = DoSearch(ref pos, nPiece ^ 1, nDepth + 1, Temp, nAlpha, nBeta);
					nAlpha = Math.Max(nAlpha, nValue );

					// Check to see if this result is greater than the current max.
					if( nDepth == 0 && nTempValue < nAlpha )
					{
						pos.src = MoveList[i*2];
						pos.dst = MoveList[i*2+1]; 
					}

					if (nValue >= nBeta)
					{
						return (nValue);
					}
				}

				return nAlpha;
			}

			// Minimzer
			else
			{
				// Loop through the legal moves.
				for (int i = 0; i < MoveList.Length/2; i++)
				{
					// We need a board clone so that we can place pieces
					//   without messing up previous board positions.
					ChessEngine Temp = brd.Clone();
			
					// Place the piece from the current move in the list.
					Temp.MakeHumanMove(MoveList[i * 2], MoveList[i * 2 + 1], false);
			
					// Call DoSearch() recursively.
					nValue = DoSearch(ref pos, nPiece ^ 1, nDepth + 1, Temp, nAlpha, nBeta);
					nBeta = Math.Min(nBeta, nValue);

					if (nValue <= nAlpha) 
					{
						return (nValue);
					}
				}
				return nBeta;
			}

			return (0);
		}

		int[] ReOrder( int[] MoveList, ChessEngine brd )
		{
			int[] Ret = new int[MoveList.Length];

			int dst = 0;

			for( int i=0; i<MoveList.Length/2; i++ )
			{
				if( brd.GetPiece( MoveList[i*2+1] ) != 0 )
				{
					Ret[dst * 2] = MoveList[i * 2];
					Ret[dst * 2+1] = MoveList[i * 2+1];
					dst++;
				}
			}

			for (int i = 0; i < MoveList.Length/2; i++)
			{
				if (brd.GetPiece(MoveList[i * 2 + 1]) == 0)
				{
					Ret[dst * 2] = MoveList[i * 2];
					Ret[dst * 2 + 1] = MoveList[i * 2 + 1];
					dst++;
				}
			}

			return (Ret);
		}

	}

}
