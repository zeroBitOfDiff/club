﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ChessDemo
{
	class Utils
	{
		const int BOARDYOFFSET = 63;
		const int BOARDXOFFSET = 43;
		const int SQUAREHEIGHT = 40;
		const int TOPWIDTH = 52;
		const int BOTTOMWIDTH = 69;
		const int RISE = 320;
		const int BASEHEIGHT = 15;

		static int XCoord(int nY, int nCol)
		{
			int nRise, nRun, nX, b;

			nRise = RISE;
			nRun = (BOTTOMWIDTH + nCol * TOPWIDTH) - (nCol * BOTTOMWIDTH);
			if (nRun != 1)
			{
				b = -(short)(((long)nRise * (long)nCol * BOTTOMWIDTH) / (long)nRun);
				nX = (short)(((long)nRun * (long)(nY - b)) / (long)nRise);
			}
			else
			{
				nX = nCol * BOTTOMWIDTH;
			}

			return (nX + BOARDXOFFSET);
		}

		static public void GetPolygonVertices(int nSquare, ref Point[] objArray)
		{
			int nRow, nCol, _nTopY, _nBottomY, nTopY, nBottomY;
			nRow = 7 - (nSquare >> 3);
			nCol = nSquare & 7;

			nTopY = _nTopY = BOARDYOFFSET + SQUAREHEIGHT * 8 - SQUAREHEIGHT - nRow * SQUAREHEIGHT;
			nBottomY = _nBottomY = nTopY + SQUAREHEIGHT;
			_nTopY = (BOARDYOFFSET + SQUAREHEIGHT * 8) - nTopY;
			if (_nTopY < 0)
			{
				_nTopY = 0;
			}
			_nBottomY = (BOARDYOFFSET + SQUAREHEIGHT * 8) - nBottomY;
			if (_nBottomY < 0)
			{
				_nBottomY = 0;
			}

			objArray[0].X = XCoord(_nTopY, nCol);
			objArray[0].Y = objArray[1].Y = nTopY;
			objArray[1].X = XCoord(_nTopY, nCol + 1);
			objArray[2].X = XCoord(_nBottomY, nCol + 1);
			objArray[2].Y = objArray[3].Y = nBottomY + 1;
			objArray[3].X = XCoord(_nBottomY, nCol);
			objArray[4].X = objArray[0].X;
			objArray[4].Y = objArray[0].Y;

			for (int i = 0; i < objArray.Length; i++)
			{
				objArray[i].Y += (int)((float)(7 - nRow) * (float)1.6);
				objArray[i].Y += 4;
			}

		}

		public static bool IsInPolygon(Point[] objPoly, Point p)
		{
			Point p1, p2;
			bool bInside = false;

			if (objPoly.Length < 3)
			{
				return (bInside);
			}

			var objOldPoint = new Point(objPoly[objPoly.Length - 1].X, objPoly[objPoly.Length - 1].Y);

			for (int i = 0; i < objPoly.Length; i++)
			{
				var objNewPoint = new Point(objPoly[i].X, objPoly[i].Y);

				if (objNewPoint.X > objOldPoint.X)
				{
					p1 = objOldPoint;
					p2 = objNewPoint;
				}
				else
				{
					p1 = objNewPoint;
					p2 = objOldPoint;
				}

				if ((objNewPoint.X < p.X) == (p.X <= objOldPoint.X)
					&& (p.Y - (long)p1.Y) * (p2.X - p1.X)
					< (p2.Y - (long)p1.Y) * (p.X - p1.X))
				{
					bInside = !bInside;
				}

				objOldPoint = objNewPoint;
			}

			return bInside;
		}

		static public bool GetSquare(int nX, int nY, ref int nRow, ref int nCol)
		{

			if (nY >= 67 && nY < 399)
			{
				nRow = (int)((float)(nY - 67) / (float)41.5);

				Point p = new Point(nX, nY);

				for (nCol = 0; nCol < 8; nCol++)
				{
					Point[] objArray = new Point[5];
					GetPolygonVertices(nRow * 8 + nCol, ref objArray);

					if (IsInPolygon(objArray, p))
					{
						return (true);
					}
				}
			}

			return (false);
		}

		static public int NumberFromImageName(string strUri)
		{
			strUri = strUri.ToUpper();

			if (strUri.IndexOf("1.PNG") >= 0)
			{
				return (1);
			}
			if (strUri.IndexOf("2.PNG") >= 0)
			{
				return (2);
			}
			if (strUri.IndexOf("3.PNG") >= 0)
			{
				return (3);
			}
			if (strUri.IndexOf("4.PNG") >= 0)
			{
				return (4);
			}
			if (strUri.IndexOf("5.PNG") >= 0)
			{
				return (5);
			}
			if (strUri.IndexOf("6.PNG") >= 0)
			{
				return (6);
			}
			return (0);
		}

		static public void MemsetIntArray(ref int[] Array)
		{
			for (int i = 0; i < Array.Length; i++)
			{
				Array[i] = 0;
			}
		}

		static public int FILE(int a)
		{
			return (a & 7);
		}

		static public int RANK(int a)
		{
			return (a >> 3);
		}
	}
}
