﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ChessDemo
{
	public partial class Form1 : Form
	{

		Bitmap objChessBoard;
		Bitmap[] objPiece;
		static string[] PieceImageNames = { "TWP.png", "TWN.png", "TWB.png", "TWR.png", "TWQ.png", "TWK.png",
											"TBP.png", "TBN.png", "TBB.png", "TBR.png", "TBQ.png", "TBK.png" };

		ChessEngine objEngine = new ChessEngine();
		Minimax objMinMax = new Minimax();

		void LoadImages()
		{
			objChessBoard = new Bitmap(@"images\ChessBoard.jpg");
			objPiece = new Bitmap[PieceImageNames.Length];
			for (int i = 0; i < PieceImageNames.Length; i++) objPiece[i] = new Bitmap(String.Format("images/{0}", PieceImageNames[i] ));
		}

		public Form1()
		{
			InitializeComponent();
			LoadImages();
			objEngine.Restart();
			objMinMax.init();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
		}

		Point GetSquareCoords( int sq )
		{
			Point ret = new Point( ( sq % 8 ) * 75, ( sq / 8 ) * 75 );
			return (ret);
		}

		private void OnPaint(object sender, PaintEventArgs e)
		{
			e.Graphics.DrawImage(objChessBoard, 20, 60);

			for( int sq=0; sq<64; sq++ )
			{
				int Color = objEngine.GetColor(sq);
				int Piece = objEngine.GetPiece(sq);

				if( Color == ChessConstants.WHITE &&
					Piece != ChessConstants.NONE )
				{
					Point pt = GetSquareCoords(sq);
					e.Graphics.DrawImage(objPiece[Piece - 1], 50 + pt.X, pt.Y );
				}
				else if (Color == ChessConstants.BLACK &&
					Piece != ChessConstants.NONE)
				{
					Point pt = GetSquareCoords(sq);
					e.Graphics.DrawImage(objPiece[Piece - 1 + 6], 50 + pt.X, pt.Y + 28);
				}

			}

		}

		private void button1_Click(object sender, EventArgs e)
		{
			MoveInfo pos = new MoveInfo();
			DateTime dt = DateTime.Now;
			objMinMax.GetMove(ref pos, ref objEngine, objEngine.GetSide() );
			TimeSpan ts = DateTime.Now - dt;
			// MessageBox.Show(String.Format("{0} {1} {2}", ts.Hours, ts.Minutes, ts.Seconds ));
			objEngine.MakeHumanMove(pos.src, pos.dst, false);

			Refresh();
		}

	}
}
