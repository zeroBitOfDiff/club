﻿using System;
using System.Net;
using System.Windows;

namespace ChessDemo
{
	public class ChessConstants
	{

		public struct MOVE
		{
			public int SrcSq;
			public int DestSq;
			public int SrcPiece;
			public int DestPiece;
			public int SrcColor;
			public int DestColor;
			public int Promotion;
			public int EnpassantPos;
			public int flags;
			public int time;
		};

		public struct hashval
		{
			public UInt32 key, bd;
		};

		public const int PLY3 = 1;
		public const int WINDOWSCORE = 1;
		public const int DOBESTS = 1;

		public const int WHITE = 0;
		public const int BLACK = 1;
		public const int NEUTRAL = 2;

		public const int LEFT = 0;
		public const int RIGHT = 1;

		/*
			Piece Defines.
		*/
		public const int NONE = 0;
		public const int PAWN = 1;
		public const int KNIGHT = 2;
		public const int BISHOP = 3;
		public const int ROOK = 4;
		public const int QUEEN = 5;
		public const int KING = 6;

		/*
			Bit values which indicate information about a move.
		*/
		public const int MF_ILLEGAL = 0x00000001;
		public const int MF_NORMAL = 0x00000002;

		public const int MF_PAWNCAP = 0x00000004;
		public const int MF_KNIGHTCAP = 0x00000008;
		public const int MF_BISHCAP = 0x00000010;
		public const int MF_ROOKCAP = 0x00000020;
		public const int MF_QUEENCAP = 0x00000040;
		public const int MF_CAPTURE = 0x0000007c;
		public const int MF_CHECK = 0x00000080;
		public const int MF_MATE = 0x00000100;
		public const int MF_STALE = 0x00000200;
		public const int MF_DRAW = 0x00000400;
		public const int MF_CASTLEKING = 0x00000800;
		public const int MF_CASTLEQUEEN = 0x00001000;
		public const int MF_ENPASSANTE = 0x00002000;
		public const int MF_GAMEOVER = 0x00004000;
		public const int MF_PROMOTION = 0x00008000;
		public const int MF_LACKOFFORCE = 0x00010000;
		public const int MF_NULLMOVE = 0x00020000;
		public const int MF_FIFTYMOVE = 0x00040000;
		public const int MF_DRAWBYREPETITION = 0x00080000;

		public const int EF_GOODMOVE = 0x00000001;
		public const int EF_VERYGOODMOVE = 0x00000002;
		public const int EF_BADMOVE = 0x00000004;
		public const int EF_VERYBADMOVE = 0x00000008;
		public const int EF_WGOODEXCHANGE = 0x00000010;
		public const int EF_BGOODEXCHANGE = 0x00000020;
		public const int EF_WBADEXCHANGE = 0x00000040;
		public const int EF_BBADEXCHANGE = 0x00000080;
		public const int EF_WGAINEDMATERIALADV = 0x00000100;
		public const int EF_BGAINEDMATERIALADV = 0x00000200;
		public const int EF_WLOSTMATERIALADV = 0x00000400;
		public const int EF_BLOSTMATERIALADV = 0x00000800;
		public const int EF_WGAINEDCENTERCTRL = 0x00001000;
		public const int EF_BGAINEDCENTERCTRL = 0x00002000;
		public const int EF_WLOSTCENTERCTRL = 0x00004000;
		public const int EF_BLOSTCENTERCTRL = 0x00008000;
		public const int EF_WKINGWELLPROTECTED = 0x00010000;
		public const int EF_BKINGWELLPROTECTED = 0x00020000;
		public const int EF_WKINGNOTWELLPROTECTED = 0x00040000;
		public const int EF_BKINGNOTWELLPROTECTED = 0x00080000;

		public const int EF_SAMEPIECEMOVEPOSSIBLE = 0x00100000;
		public const int EF_SAMEPIECESAMEFILE = 0x00200000;

		public enum CHESS_MOVE_TYPES
		{
			RF_PAWNPOSITION, RF_KNIGHTPOSITION, RF_BISHOPPOSITION,
			RF_ROOKPOSITION, RF_QUEENPOSITION,
			RF_CENTERPOSITION, RF_DEVELOPMENT, RF_PROMOTION,
			RF_MATERIAL, RF_OVERALLSCORE, RF_GOODMOVE, RF_CHECKMATE,
			RF_CHECK, RF_OPENINGBOOK,
			RF_AVOIDLOSINGMATERIAL, RF_GOODCAPTURE, RF_TRADEPIECES,
			RF_FORCECHECKMATE,
			RF_KNIGHTFORK, RF_PIN,
			RF_DISCOVEREDCHECK,
			RF_AVOIDCHECK,
			RF_ADVANTAGEOUSATTACK,
			RF_TAKEPAWN,
			RF_CASTLE,
			RF_ADVANTAGEOUSANDDEVELOP,
			RF_CENTERANDBISHOP, RF_CENTERANDROOK, RF_CENTERANDQUEEN,
			RF_PAWNANDBISHOP, RF_PAWNANDROOK, RF_PAWNANDQUEEN,
			RF_SKEWER, RF_FIANCHETTO,
			RF_PINDEV, RF_SKEWERDEV,
			RF_COMPLETETRADE, RF_OFFERTRADE,
			RF_AVOIDANDTAKE,
			RF_ADVANTAGEOUSANDDEVELOP_MAT, RF_ADVANTAGEOUSATTACK_MAT,
			RF_ENPASSANTE, RF_AVOIDANDATTACK,
			RF_MOVETOPROTECTION, RF_TAKEPIECE
		};

		public const int MAXMOVES = 400;
		public const int MAXTICKS = 800;

		public const int PAWNRAMBONUS = -7;
		public const int EIGHTPAWNBONUS = -6;
		public const int ISOLATEDPAWN0 = -7;
		public const int ISOLATEDPAWN1 = -3;
		public const int KNIGHTDISTANCE0 = 3;
		public const int OUTPOSTKNIGHTBONUS0 = 2;
		public const int OUTPOSTKNIGHTBONUS1 = 3;
		public const int TWOBISHOPBONUS = 13;
		public const int BISHOPSCAN0 = 4;
		public const int BISHOPSCAN1 = 1;
		public const int ROOKSCAN0 = 4;
		public const int ROOKHALF0 = 12;
		public const int ROOKHALF1 = 4;
		public const int ROOKSEVENTHBONUS = 14;
		public const int PRECASTLEROOKBONUS = 22;
		public const int PRECASTLEROOKPENALTY = -58;
		public const int QUEENDISTANCE0 = 2;
		public const int CASTLEBONUS = 80;
		public const int CASTLEPENALTY = -60;
		public const int CASTLEAVAIL = 50;
		public const int ROOKDISTANCE0 = 3;
		public const int EXPOSEDQK0 = 3;
		public const int KINGOFFROWBONUS = 11;
		public const int DEVELOPBONUS = 30;
		public const int QUEENEARLYMOVE = -80;
		public const int PASSEDPAWN0 = 5;
		public const int MAXBESTS = 35;

		public const int MAXDEPTH = 7;

		public const int rehash = 5;
		public const int MAXrehash = 6;
		public const int vttblsz = (1 << 16);
		public const int ttblsz = vttblsz;
	}
}
