﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessDemo
{
	class ChessEngine
	{
		#region CLASS_MEMBERS
		int[] Developed = new int[2], Develop = new int[2];

		int[] KingRow = new int[2];
		int[] KingCol = new int[2];
		int[] KingPos = new int[2];
		int[] KingMoves = new int[2];

		int[] BestList = new int[100];
		int[] BestScores = new int[50];

		int[] jnk = new int[200];
		int[] EightPawns = new int[2];

		int oldply, movesrc, movedst, moveside;
		bool EndGame;
		int[] MoveQueue = new int[100];
		int[] LastMoved = new int[12];

		static int[] PieceFlags = { 0, ChessConstants.MF_PAWNCAP, ChessConstants.MF_KNIGHTCAP, ChessConstants.MF_BISHCAP, ChessConstants.MF_ROOKCAP, ChessConstants.MF_QUEENCAP, 0 };

		static int[] Materials = { 0, 100, 300, 320, 500, 900, 0 };

		int RepetitionSrc, RepetitionDest;

		int[,] SaveList = new int[10, 300];
		int[,] PawnsOnFile = new int[2, 8];
		UInt32 stime, etime, htime, sfirst;
		int[] Pawns = new int[2];

		int[] Material = new int[2];
		int[] TwoBishopBonus = new int[2];
		int[] OpenFiles = new int[2];

		static int[] cpb = { -22, 15, 25 };
		static int[] s = { 7, 7, 7, -1, 3, -3, -11, -15, -12 };
		static int[] cent = { -8, -5, 5, 17, 13, 8, -3, -11 };

		static int[] __sc = 
		{
			0, 1, 0, 1, 0, 1, 0, 1,
			1, 0, 1, 0, 1, 0, 1, 0,
			0, 1, 0, 1, 0, 1, 0, 1,
			1, 0, 1, 0, 1, 0, 1, 0,
			0, 1, 0, 1, 0, 1, 0, 1,
			1, 0, 1, 0, 1, 0, 1, 0,
			0, 1, 0, 1, 0, 1, 0, 1,
			1, 0, 1, 0, 1, 0, 1, 0
		};

		int Side;

		ChessConstants.MOVE[] MoveList;
		int[] FlagList;

		int[] WantStalemate = new int[2];

		int[] Beta = new int[ChessConstants.MAXMOVES];
		int[] Capt = new int[ChessConstants.MAXMOVES];
		int[] EnpassantPos = new int[2];

		int[,] RookMoves = new int[2, 2], RookPos = new int[2, 2];
		int[] KingSq = new int[2];

		int m_nBeforeAttackOnMeCount;
		int[] m_nBeforeAttackOnMeList;

		int[] KINGSq = new int[2];

		int BestCount;

		int[] m_nScore = new int[ChessConstants.MAXMOVES],
			m_nPawnScore = new int[ChessConstants.MAXMOVES],
			m_nKnightScore = new int[ChessConstants.MAXMOVES],
			m_nBishopScore = new int[ChessConstants.MAXMOVES],
			m_nRookScore = new int[ChessConstants.MAXMOVES],
			m_nMaterial = new int[ChessConstants.MAXMOVES],
			m_nQueenScore = new int[ChessConstants.MAXMOVES],
			m_nCenterControl = new int[ChessConstants.MAXMOVES],
			m_nDevelopment = new int[ChessConstants.MAXMOVES];

		int CurrentMove, MaxMove;
		bool[] Castled = new bool[2];
		int[] KINGMoves = new int[2];
		int[,] ROOKMoves = new int[2, 2];
		int[,] ROOKPos = new int[2, 2];
		int mOpening;
		int m_nMoveStep;
		int m_nInitMoves;

		int[] BoardPiece = new int[64];
		int[] BoardColor = new int[64];

		static int[,] distdata = new int[64, 64];
		static int[,] taxidata = new int[64, 64];

		int m_nBetaDifference;
		bool m_bTimedGame;
		int m_nTimedOpening;

		int[] m_nLookForForceList = new int[20];
		int[,] m_nLastLookFor = new int[2, 2];

		bool m_bEdited;

		int Thinking;
		int SDepth, SearchDepth;
		int MaxBests;
		int PVSrc, PVDst;
		int Promotion = 0;
		int[] SkillLevel = new int[2];
		bool GameOver;
		bool Switched;
		int LastSrcCl, LastDstPc, LastDstCl, LastSrc, LastDst;
		int LastSrcPc;
		#endregion

		#region CLASS_CONSTRUCTOR
		public ChessEngine()
		{
			MoveList = new ChessConstants.MOVE[ChessConstants.MAXMOVES];
			FlagList = new int[ChessConstants.MAXMOVES];

			m_bEdited = false;
			Thinking = 0;
			SDepth = SearchDepth = ChessConstants.MAXDEPTH;
			MaxBests = ChessConstants.MAXBESTS;
			PVSrc = PVDst = -1;
			Promotion = 0;
			SkillLevel[0] = SkillLevel[1] = 5;
			GameOver = true;
			Switched = false;
			LastSrcCl = LastDstPc = LastDstCl = LastSrc = LastDst = 0;
			LastSrcPc = 1;
			mOpening = -1;
			BestCount = 0;
		}
		#endregion

		/*
			Restart the game by resetting all variables and arrays.
		*/
		public void Restart()
		{
			int i;

			GameOver = false;
			mOpening = -1;
			_InitializeDistance();

			/*
				SkillLevel[?] will be a value from 1-9. When the program
				first runs it'll be initialized to 0. If the Restart()
				code gets here and finds that SkillLevel is 0, it's
				set to the default of 5.
			*/
			if (SkillLevel[0] == 0) SkillLevel[0] = SkillLevel[1] = 5;

			/*
				Copy the default board and color arrangement into the working arrays.
			*/
			for (i = 0; i < 64; i++)
			{
				BoardPiece[i] = ChessData.StartBoardPieces[i];
				BoardColor[i] = ChessData.StartBoardColors[i];
			}

			/*
				Since we're restarting the game, it's White's turn.
			*/
			Side = ChessConstants.WHITE;

			/*
				Set the CurrentMove and MaxMove variables so that we'll
				get a fresh start in the move list.
			*/
			CurrentMove = MaxMove = 0;

			Castled[ChessConstants.WHITE] = Castled[ChessConstants.BLACK] = false;
			KingMoves[ChessConstants.WHITE] = KingMoves[ChessConstants.BLACK] = 0;
			RookMoves[ChessConstants.WHITE, ChessConstants.LEFT] = RookMoves[ChessConstants.WHITE, ChessConstants.RIGHT] = RookMoves[ChessConstants.BLACK, ChessConstants.LEFT] = RookMoves[ChessConstants.BLACK, ChessConstants.RIGHT] = 0;
			RookPos[ChessConstants.WHITE, ChessConstants.LEFT] = 56;
			RookPos[ChessConstants.WHITE, ChessConstants.RIGHT] = 63;
			RookPos[ChessConstants.BLACK, ChessConstants.LEFT] = 0;
			RookPos[ChessConstants.BLACK, ChessConstants.RIGHT] = 7;
			EnpassantPos[ChessConstants.WHITE] = EnpassantPos[ChessConstants.BLACK] = -1;

		}

		/*
			Set the skill level for a color.
		*/
		void SetSkillLevel(int level, int color)
		{

			if (level > 9) level = 9;
			else if (level < 0) level = 0;
			if (color > ChessConstants.BLACK) color = ChessConstants.BLACK;
			else if (color < ChessConstants.WHITE) color = ChessConstants.WHITE;

			SkillLevel[color] = level + 1;

		}

		/*
			Get the skill level for a color.
		*/
		int GetSkillLevel(int color)
		{

			/*
				Make sure the color is in range.
			*/
			if (color > ChessConstants.BLACK) color = ChessConstants.BLACK;
			else if (color < ChessConstants.WHITE) color = ChessConstants.WHITE;

			return (SkillLevel[color]);

		}

		/*
			Get the number of legal moves for a square.
		*/
		int GetLegalMoveCount(int Sq)
		{
			int[] List = new int[100];

			if (GameOver) return (0);

			return (GetLegalMoveList(Sq, ref List));

		}

		/*
			Fill in the passed array with the legal moves for the given square.
		*/
		public int GetLegalMoveList(int Sq, ref int[] List)
		{
			int Count, i;

			if (GameOver) return (0);

			if (Switched) Sq = 63 - Sq;

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			Count = _LegalMoves(Sq, ref List);
			Count = _RemoveKingInCheck(Count, Sq, ref List, Side);

			if (Switched)
			{
				for (i = 0; i < Count; i++) List[i] = 63 - List[i];
			}

			return (Count);

		}

		/*
			Get the number of legal squares from which a square is under attack.
		*/
		int GetAttackMoveCount(int Sq)
		{
			int[] List = new int[100];

			if (GameOver) return (0);

			return (GetAttackMoveList(Sq, ref List));

		}

		/*
			Fill in the passed array with the squares from which a square is under attack.
		*/
		int GetAttackMoveList(int _Sq, ref int[] List)
		{
			int Count;
			int[] _List = new int[100];
			int Sq, i, index = 0;

			if (GameOver) return (0);

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			Side ^= 1;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					Count = _LegalMoves(Sq, ref _List);
					if (BoardPiece[_Sq] != ChessConstants.KING) Count = _RemoveKingInCheck(Count, Sq, ref _List, Side);
					for (i = 0; i < Count; i++)
					{
						if (_List[i] == _Sq)
						{
							List[index++] = Sq;
							i = Count;
						}
					}
				}
			}

			Side ^= 1;

			return (index);

		}

		int GetSupportMoveList(int _Sq, ref int[] List)
		{
			int Count;
			int[] _List = new int[100];
			int Sq, i, index = 0;

			if (GameOver) return (0);

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			Side ^= 1;
			int OldColor = BoardColor[_Sq];
			int OldPiece = BoardPiece[_Sq];
			BoardColor[_Sq] = Side ^ 1;
			BoardPiece[_Sq] = ChessConstants.PAWN;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					Count = _LegalMoves(Sq, ref _List);
					Count = _RemoveKingInCheck(Count, Sq, ref _List, Side);
					for (i = 0; i < Count; i++)
					{
						if (_List[i] == _Sq)
						{
							List[index++] = Sq;
							i = Count;
						}
					}
				}
			}

			Side ^= 1;
			BoardColor[_Sq] = OldColor;
			BoardPiece[_Sq] = OldPiece;

			return (index);

		}

		/*
			Fill in the passed array with the squares from which a square is under attack.
		*/
		int GetAttackMoveListOnBlankSquare(int _Sq, ref int[] List)
		{
			int Count;
			int[] _List = new int[100];
			int Sq, i, index = 0;

			if (GameOver) return (0);

			if (BoardColor[_Sq] != ChessConstants.NEUTRAL) return (0);
			BoardColor[_Sq] = Side;
			BoardPiece[_Sq] = ChessConstants.PAWN;
			if (_InCheck(Side ^ 1)) BoardPiece[_Sq] = ChessConstants.ROOK;

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			Side ^= 1;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					Count = _LegalMoves(Sq, ref _List);
					if (BoardPiece[_Sq] != ChessConstants.KING) Count = _RemoveKingInCheck(Count, Sq, ref _List, Side);
					for (i = 0; i < Count; i++)
					{
						if (_List[i] == _Sq) List[index++] = Sq;
					}
				}
			}

			Side ^= 1;

			BoardColor[_Sq] = ChessConstants.NEUTRAL;
			BoardPiece[_Sq] = 0;

			return (index);

		}

		int _GetCenterAttacks(int _Sq, ref int[] List, int Side)
		{
			int Count;
			int[] _List = new int[100];
			int Sq, i, index = 0;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] != ChessConstants.NEUTRAL && BoardPiece[Sq] != ChessConstants.PAWN)
				{
					Count = _LegalMoves(Sq, ref _List);
					if (BoardPiece[_Sq] != ChessConstants.KING) Count = _RemoveKingInCheck(Count, Sq, ref _List, BoardColor[Sq]);
					for (i = 0; i < Count; i++)
					{
						if (_List[i] == _Sq) List[index++] = Sq;
					}
				}
			}

			return (index);

		}

		/*
			Returns TRUE if a move from SrcSq to DestSq is legal.
			Returns FALSE if the move is not legal.
		*/
		int IsMoveLegal(int SrcSq, int DestSq)
		{
			int Count, i;
			int[] List = new int[100];
			int found = 0;

			if (GameOver) return (0);

			if (Switched)
			{
				SrcSq = 63 - SrcSq;
				DestSq = 63 - DestSq;
			}

			Count = _LegalMoves(SrcSq, ref List);
			Count = _RemoveKingInCheck(Count, SrcSq, ref List, Side);

			for (i = 0; i < Count; i++)
			{
				if (DestSq == List[i])
				{
					found = 1;
					i = Count;
				}
			}

			return (found);

		}

		/*
			Returns TRUE if a move from SrcSq to DestSq is legal.
			Returns FALSE if the move is not legal.
		*/
		int _IsMoveLegal(int SrcSq, int DestSq)
		{
			int Count, i;
			int[] List = new int[100];
			int found = 0;

			Count = _LegalMoves(SrcSq, ref List);
			Count = _RemoveKingInCheck(Count, SrcSq, ref List, Side);

			for (i = 0; i < Count; i++)
			{
				if (DestSq == List[i])
				{
					found = 1;
					i = Count;
				}
			}

			return (found);

		}

		/*
			Set the board pieces and colors.
		*/
		void SetBoard(ref int[] Pieces, ref int[] Colors)
		{
			int i;

			if (Switched)
			{
				for (i = 0; i < 64; i++)
				{
					BoardPiece[63 - i] = Pieces[i];
					BoardColor[63 - i] = Colors[i];
				}
			}
			else
			{
				for (i = 0; i < 64; i++)
				{
					BoardPiece[i] = Pieces[i];
					BoardColor[i] = Colors[i];
				}
			}

		}

		/*
			Fill in the passed arrays with the current pieces and colors.
		*/
		void GetBoard(ref int[] Pieces, ref int[] Colors)
		{
			int i;

			if (Switched)
			{
				for (i = 0; i < 64; i++)
				{
					Pieces[63 - i] = BoardPiece[i];
					Colors[63 - i] = BoardColor[i];
				}
			}
			else
			{
				for (i = 0; i < 64; i++)
				{
					Pieces[i] = BoardPiece[i];
					Colors[i] = BoardColor[i];
				}
			}

		}

		public void SetPiece(int Sq, int Piece, int Color)
		{
			if (Sq > 63) Sq = 63;
			else if (Sq < 0) Sq = 0;

			if (Switched) Sq = 63 - Sq;

			BoardPiece[Sq] = Piece;
			BoardColor[Sq] = Color;
		}

		/*
			Get the piece type on a square.
		*/
		public int GetPiece(int Sq)
		{

			if (Sq > 63) Sq = 63;
			else if (Sq < 0) Sq = 0;

			if (Switched) Sq = 63 - Sq;

			return (BoardPiece[Sq]);

		}

		/*
			Get the piece color on a square.
		*/
		public int GetColor(int Sq)
		{

			if (Sq > 63) Sq = 63;
			else if (Sq < 0) Sq = 0;

			if (Switched) Sq = 63 - Sq;

			return (BoardColor[Sq]);

		}

		/*
			Return the side whose turn it is.
		*/
		public int GetSide()
		{

			return (Side);

		}

		/*
			Make a human move from SrcSq to DestSq. The returned value indicates
			information about the move such as captures and checks.
		*/
		public int MakeHumanMove(int SrcSq, int DestSq, bool flag)
		{
			int SrcPc, SrcCl, DestPc, DestCl, EnpSq;
			int fil, enflag = 0, i;
			int flags = 0;
			int capture = 0;

			//	if( GameOver ) return( MF_GAMEOVER );

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			if (Switched && flag)
			{
				SrcSq = 63 - SrcSq;
				DestSq = 63 - DestSq;
			}

			if (_IsMoveLegal(SrcSq, DestSq) == 0) return (ChessConstants.MF_ILLEGAL);

			/*
				Get the source and destination square pieces and colors
				so that we can move and then restore them.
			*/
			LastSrc = SrcSq;
			LastDst = DestSq;
			LastSrcPc = SrcPc = BoardPiece[SrcSq];
			LastSrcCl = SrcCl = BoardColor[SrcSq];
			LastDstPc = DestPc = BoardPiece[DestSq];
			LastDstCl = DestCl = BoardColor[DestSq];

			Capt[CurrentMove] = Materials[BoardPiece[DestSq]];

			/*
				Make the move.
			*/
			BoardPiece[SrcSq] = ChessConstants.NONE;
			BoardColor[SrcSq] = ChessConstants.NEUTRAL;
			BoardPiece[DestSq] = SrcPc;
			BoardColor[DestSq] = SrcCl;

			if (Promotion != 0) BoardPiece[DestSq] = Promotion;

			flags |= PieceFlags[DestPc];

			MoveList[CurrentMove].SrcSq = (char)SrcSq;
			MoveList[CurrentMove].SrcPiece = (char)SrcPc;
			MoveList[CurrentMove].SrcColor = (char)SrcCl;
			MoveList[CurrentMove].DestSq = (char)DestSq;
			MoveList[CurrentMove].DestPiece = (char)DestPc;
			MoveList[CurrentMove].DestColor = (char)DestCl;
			MoveList[CurrentMove].Promotion = (char)Promotion;

			if (SrcPc == ChessConstants.PAWN)
			{
				if (SrcCl == ChessConstants.WHITE)
				{
					if (Utils.RANK(DestSq) == 4)
					{
						fil = Utils.FILE(DestSq);
						if (fil > 0 && BoardColor[DestSq - 1] == (SrcCl ^ 1) && BoardPiece[DestSq - 1] == ChessConstants.PAWN)
						{
							enflag = 1;
							EnpassantPos[SrcCl ^ 1] = SrcSq - 8;
						}
						if (fil < 7 && BoardColor[DestSq + 1] == (SrcCl ^ 1) && BoardPiece[DestSq + 1] == ChessConstants.PAWN)
						{
							enflag = 1;
							EnpassantPos[SrcCl ^ 1] = SrcSq - 8;
						}
					}
				}
				else
				{
					if (Utils.RANK(DestSq) == 3)
					{
						fil = Utils.FILE(DestSq);
						if (fil > 0 && BoardColor[DestSq - 1] == (SrcCl ^ 1) && BoardPiece[DestSq - 1] == ChessConstants.PAWN)
						{
							enflag = 1;
							EnpassantPos[SrcCl ^ 1] = SrcSq + 8;
						}
						if (fil < 7 && BoardColor[DestSq + 1] == (SrcCl ^ 1) && BoardPiece[DestSq + 1] == ChessConstants.PAWN)
						{
							enflag = 1;
							EnpassantPos[SrcCl ^ 1] = SrcSq + 8;
						}
					}
				}
			}
			else if (SrcPc == ChessConstants.KING) KingMoves[SrcCl]++;
			else if (SrcPc == ChessConstants.ROOK)
			{
				if (SrcSq == RookPos[SrcCl, ChessConstants.LEFT])
				{
					RookPos[SrcCl, ChessConstants.LEFT] = DestSq;
					RookMoves[SrcCl, ChessConstants.LEFT]++;
				}
				else
				{
					RookPos[SrcCl, ChessConstants.RIGHT] = DestSq;
					RookMoves[SrcCl, ChessConstants.RIGHT]++;
				}
			}

			if (enflag == 0) EnpassantPos[SrcCl] = -1;
			else Capt[CurrentMove] = 100;

			/*
				Handle enpassante move.
			*/
			if (SrcPc == ChessConstants.PAWN && DestPc == 0 && Utils.FILE(SrcSq) != Utils.FILE(DestSq))
			{
				flags |= ChessConstants.MF_ENPASSANTE;
				if (SrcCl == ChessConstants.WHITE)
				{
					if (Utils.FILE(SrcSq) > Utils.FILE(DestSq)) EnpSq = SrcSq - 1;
					else EnpSq = SrcSq + 1;
				}
				else
				{
					if (Utils.FILE(SrcSq) < Utils.FILE(DestSq)) EnpSq = SrcSq + 1;
					else EnpSq = SrcSq - 1;
				}
				BoardPiece[EnpSq] = ChessConstants.NONE;
				BoardColor[EnpSq] = ChessConstants.NEUTRAL;
			}

			/*
				Handle castle move.
			*/
			else if (SrcPc == ChessConstants.KING && (Utils.FILE(SrcSq) == 3 || Utils.FILE(SrcSq) == 4) && Math.Abs((Utils.FILE(SrcSq) - Utils.FILE(DestSq))) > 1)
			{
				if (SrcCl == ChessConstants.WHITE)
				{
					Castled[ChessConstants.WHITE] = true;
					if (Utils.FILE(DestSq) > 4)
					{
						BoardPiece[61] = ChessConstants.ROOK;
						BoardColor[61] = ChessConstants.WHITE;
						BoardPiece[63] = ChessConstants.NONE;
						BoardColor[63] = ChessConstants.NEUTRAL;
						flags |= ChessConstants.MF_CASTLEKING;
					}
					else
					{
						BoardPiece[59] = ChessConstants.ROOK;
						BoardColor[59] = ChessConstants.WHITE;
						BoardPiece[56] = ChessConstants.NONE;
						BoardColor[56] = ChessConstants.NEUTRAL;
						flags |= ChessConstants.MF_CASTLEQUEEN;
					}
				}
				else
				{
					Castled[ChessConstants.BLACK] = true;
					if (Utils.FILE(DestSq) > 4)
					{
						BoardPiece[5] = ChessConstants.ROOK;
						BoardColor[5] = ChessConstants.BLACK;
						BoardPiece[7] = ChessConstants.NONE;
						BoardColor[7] = ChessConstants.NEUTRAL;
						flags |= ChessConstants.MF_CASTLEKING;
					}
					else
					{
						BoardPiece[3] = ChessConstants.ROOK;
						BoardColor[3] = ChessConstants.BLACK;
						BoardPiece[0] = ChessConstants.NONE;
						BoardColor[0] = ChessConstants.NEUTRAL;
						flags |= ChessConstants.MF_CASTLEQUEEN;
					}
				}
			}

			if (Side == ChessConstants.WHITE && SrcPc == ChessConstants.PAWN && Utils.RANK(DestSq) == 0)
			{
				flags |= ChessConstants.MF_PROMOTION;
			}
			else if (Side == ChessConstants.BLACK && SrcPc == ChessConstants.PAWN && Utils.RANK(DestSq) == 7)
			{
				flags |= ChessConstants.MF_PROMOTION;
			}

			Side ^= 1;

			MoveList[CurrentMove].EnpassantPos = EnpassantPos[Side];

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			if (_InCheck(Side))
			{
				flags |= ChessConstants.MF_CHECK;
				if (_InCheckMate(Side)) flags |= ChessConstants.MF_MATE;
			}

			flags |= _DrawByRepetition();
			flags |= _DrawByLackOfForce();
			//	flags |= _DrawByFifty();
			if ((flags & ChessConstants.MF_CHECK) != 0 && (flags & ChessConstants.MF_STALE) == 0) ;
			else flags |= _Stalemate(Side);

			if ((flags & ChessConstants.MF_FIFTYMOVE) != 0 || (flags & ChessConstants.MF_LACKOFFORCE) != 0 || (flags & ChessConstants.MF_DRAW) != 0 || (flags & ChessConstants.MF_STALE) != 0 || (flags & ChessConstants.MF_MATE) != 0) flags |= ChessConstants.MF_GAMEOVER;

			if (flags == 0) flags = ChessConstants.MF_NORMAL;

			//	Beta[CurrentMove] = _ScorePosition( Side ^ 1 ) - Material[Side^1] + Material[Side];
			_SetFlagSet(CurrentMove);

			MoveList[CurrentMove].flags = flags;
			CurrentMove++;
			MaxMove = CurrentMove;

			return (flags);

		}

		int _DrawByFifty()
		{

			if (CurrentMove < 50) return (0);

			for (int i = CurrentMove - 50; i < CurrentMove; i++)
			{
				if (MoveList[i].DestPiece != 0) return (0);
				if (MoveList[i].SrcPiece == ChessConstants.PAWN) return (0);
			}

			return (ChessConstants.MF_FIFTYMOVE);

		}

		/*
			Start the computer's thinking process for it's own move.
		*/
		public int StartComputerMove(ref int SrcSq, ref int DestSq, bool bMakeMove)
		{
			int i;

			BailOut = false;

			if (GameOver) return (ChessConstants.MF_GAMEOVER);

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			PVSrc = PVDst = -1;
			BestCount = 0;

			Thinking = 1;
			SearchDepth = SDepth;
			sfirst = 0;
			for (i = 0; i < 12; i++)
			{
				LastMoved[i] = -1;
			}
			moveside = Side;
			EndGame = false;
			etime = 0;
			int sc;
			stime = (uint)DateTime.Now.Millisecond;

			try
			{
				if ((sc = _search(0, Side, -31998, 31998)) == 32000)
				{
					Thinking = 2;
					return (0);
				}
			}
			catch (Exception ex)
			{
				string strError = ex.Message.ToString();
				int aaa;
				aaa = 0;
			}

			Thinking = 0;

			SrcSq = movesrc;
			DestSq = movedst;

			if (Switched)
			{
				SrcSq = 63 - movesrc;
				DestSq = 63 - movedst;
			}

			if (bMakeMove &&
				!BailOut)
			{
				return (MakeHumanMove(SrcSq, DestSq, true));
			}
			else
			{
				return (ChessConstants.MF_NORMAL);
			}

		}

		/*
			Get the computer's move.
		*/
		public int GetComputerMove(ref int SrcSq, ref int DestSq)
		{
			int i;

			if (GameOver) return (ChessConstants.MF_GAMEOVER);

			for (i = 0; i < 64; i++)
			{
				if (BoardPiece[i] == ChessConstants.KING) KingSq[BoardColor[i]] = i;
			}

			stime = (uint)DateTime.Now.Millisecond;
			sfirst = 1;
			etime = 0;
			Thinking = 2;
			int sc;

			try
			{
				if ((sc = _search(0, Side, -31998, 31998)) == 32000) return (0);
			}
			catch (Exception ex)
			{
				string strError = ex.Message.ToString();
				int ggg;
				ggg = 0;
			}

			Thinking = 0;

			SrcSq = movesrc;
			DestSq = movedst;

			if (Switched)
			{
				SrcSq = 63 - movesrc;
				DestSq = 63 - movedst;
			}

			return (MakeHumanMove(SrcSq, DestSq, true));

		}

		/*
			Attempts to fast forward one move in the move list.
		*/
		public int ForwardMove(ref int SrcSq, ref int DestSq)
		{
			int SaveMaxMove;
			int flags;

			if (CurrentMove == MaxMove) return (ChessConstants.MF_ILLEGAL);

			SrcSq = MoveList[CurrentMove].SrcSq;
			DestSq = MoveList[CurrentMove].DestSq;

			Promotion = MoveList[CurrentMove].Promotion;
			SaveMaxMove = MaxMove;
			flags = MakeHumanMove(SrcSq, DestSq, false);
			MaxMove = SaveMaxMove;
			Promotion = 0;

			if (Switched)
			{
				SrcSq = 63 - SrcSq;
				DestSq = 63 - DestSq;
			}

			return (flags);

		}

		/*
			Attempts to fast forward one move in the move list.
		*/
		bool NextMove(ref int SrcSq, ref int DestSq)
		{

			SrcSq = -1;
			if (CurrentMove == MaxMove) return (false);

			SrcSq = MoveList[CurrentMove].SrcSq;
			DestSq = MoveList[CurrentMove].DestSq;

			return (true);

		}

		/*
			Attempts to rewind one move in the move list.
		*/
		public int RewindMove(ref int SrcSq, ref int DestSq)
		{
			int EnpSq;
			int SrcPc, SrcCl;

			if (CurrentMove == 0) return (ChessConstants.MF_ILLEGAL);

			CurrentMove--;

			SrcSq = MoveList[CurrentMove].SrcSq;
			DestSq = MoveList[CurrentMove].DestSq;

			/*
				Restore the board to its original state.
			*/
			BoardPiece[SrcSq] = MoveList[CurrentMove].SrcPiece;
			BoardColor[SrcSq] = MoveList[CurrentMove].SrcColor;
			BoardPiece[DestSq] = MoveList[CurrentMove].DestPiece;
			BoardColor[DestSq] = MoveList[CurrentMove].DestColor;

			SrcPc = MoveList[CurrentMove].SrcPiece;
			SrcCl = MoveList[CurrentMove].SrcColor;

			if (SrcPc == ChessConstants.KING) KingMoves[SrcCl]--;
			else if (SrcPc == ChessConstants.ROOK)
			{
				if (SrcCl == ChessConstants.WHITE)
				{
					if (RookPos[ChessConstants.WHITE, ChessConstants.LEFT] == DestSq)
					{
						RookPos[ChessConstants.WHITE, ChessConstants.LEFT] = SrcSq;
						RookMoves[ChessConstants.WHITE, ChessConstants.LEFT]--;
						if (RookMoves[ChessConstants.WHITE, ChessConstants.LEFT] < 0) RookMoves[ChessConstants.WHITE, ChessConstants.LEFT] = 0;
					}
					else
					{
						RookPos[ChessConstants.WHITE, ChessConstants.RIGHT] = SrcSq;
						RookMoves[ChessConstants.WHITE, ChessConstants.RIGHT]--;
						if (RookMoves[ChessConstants.WHITE, ChessConstants.RIGHT] < 0) RookMoves[ChessConstants.WHITE, ChessConstants.RIGHT] = 0;
					}
				}
				else
				{
					if (RookPos[ChessConstants.BLACK, ChessConstants.LEFT] == DestSq)
					{
						RookPos[ChessConstants.BLACK, ChessConstants.LEFT] = SrcSq;
						RookMoves[ChessConstants.BLACK, ChessConstants.LEFT]--;
						if (RookMoves[ChessConstants.BLACK, ChessConstants.LEFT] < 0) RookMoves[ChessConstants.BLACK, ChessConstants.LEFT] = 0;
					}
					else
					{
						RookPos[ChessConstants.BLACK, ChessConstants.RIGHT] = SrcSq;
						RookMoves[ChessConstants.BLACK, ChessConstants.RIGHT]--;
						if (RookMoves[ChessConstants.BLACK, ChessConstants.RIGHT] < 0) RookMoves[ChessConstants.BLACK, ChessConstants.RIGHT] = 0;
					}
				}
			}

			/*
				Handle enpassante restore.
			*/
			if ((MoveList[CurrentMove].flags & ChessConstants.MF_ENPASSANTE) != 0)
			{
				EnpSq = Utils.FILE(DestSq) + Utils.RANK(SrcSq) * 8;
				BoardPiece[EnpSq] = ChessConstants.PAWN;
				BoardColor[EnpSq] = (MoveList[CurrentMove].SrcColor ^ 1);
			}

			/*
				Handle castle restore.
			*/
			else if ((MoveList[CurrentMove].flags & ChessConstants.MF_CASTLEKING) != 0)
			{
				Castled[MoveList[CurrentMove].SrcColor] = false;
				if (MoveList[CurrentMove].SrcColor == ChessConstants.WHITE)
				{
					BoardPiece[63] = ChessConstants.ROOK;
					BoardColor[63] = ChessConstants.WHITE;
					BoardPiece[61] = ChessConstants.NONE;
					BoardColor[61] = ChessConstants.NEUTRAL;
				}
				else
				{
					BoardPiece[7] = ChessConstants.ROOK;
					BoardColor[7] = ChessConstants.BLACK;
					BoardPiece[5] = ChessConstants.NONE;
					BoardColor[5] = ChessConstants.NEUTRAL;
				}
			}
			else if ((MoveList[CurrentMove].flags & ChessConstants.MF_CASTLEQUEEN) != 0)
			{
				Castled[MoveList[CurrentMove].SrcColor] = false;
				if (MoveList[CurrentMove].SrcColor == ChessConstants.WHITE)
				{
					BoardPiece[56] = ChessConstants.ROOK;
					BoardColor[56] = ChessConstants.WHITE;
					BoardPiece[59] = ChessConstants.NONE;
					BoardColor[59] = ChessConstants.NEUTRAL;
				}
				else
				{
					BoardPiece[0] = ChessConstants.ROOK;
					BoardColor[0] = ChessConstants.BLACK;
					BoardPiece[3] = ChessConstants.NONE;
					BoardColor[3] = ChessConstants.NEUTRAL;
				}
			}

			Side ^= 1;

			if (CurrentMove != 0) EnpassantPos[Side] = MoveList[CurrentMove - 1].EnpassantPos;
			else EnpassantPos[Side] = -1;

			if (Switched)
			{
				SrcSq = 63 - SrcSq;
				DestSq = 63 - DestSq;
			}

			return (MoveList[CurrentMove].flags);

		}

		public bool BailOut = false;

		/*
			Set the promoted piece type.
		*/
		int SetPromotedPiece(int Piece)
		{
			int flags = 0;

			if (CurrentMove == 0 || Piece == 0) return (0);

			MoveList[CurrentMove - 1].Promotion = (char)Piece;
			BoardPiece[MoveList[CurrentMove - 1].DestSq] = (char)Piece;

			if (_InCheck(Side))
			{
				flags |= ChessConstants.MF_CHECK;
				if (_InCheckMate(Side)) flags |= ChessConstants.MF_MATE;
			}

			return (flags);

		}

		/*
			Switch sides.
		*/
		void SwitchSides()
		{
			Switched = !Switched;
		}

		bool IsSideSwitched()
		{

			return (Switched);

		}

		/*
			Local function that returns a list of legal moves.
			This list may have moves which put a king into check.
			To remove moves which place a king in check, call RemoveKingInCheck( Count, List );
		*/
		int _LegalMoves(int Sq, ref int[] List)
		{
			int ii;
			int fil, rnk; ;
			int xSide, Side, f, r; //, index;

			int nListIndex = 0;

			Side = BoardColor[Sq];
			xSide = Side ^ 1;
			//	index = 0;
			rnk = Utils.RANK(Sq);
			fil = Utils.FILE(Sq);

			switch (BoardPiece[Sq])
			{

				case ChessConstants.PAWN:
					switch (BoardColor[Sq])
					{
						case ChessConstants.WHITE:
							if (Sq >= 8)
							{
								if (BoardColor[Sq - 8] == ChessConstants.NEUTRAL)
								{
									List[nListIndex++] = Sq - 8;
									if (Sq >= 48 && BoardColor[Sq - 16] == ChessConstants.NEUTRAL) List[nListIndex++] = Sq - 16;
								}
								if (fil > 0 && BoardColor[Sq - 9] == xSide) List[nListIndex++] = Sq - 9;
								if (fil < 7 && BoardColor[Sq - 7] == xSide) List[nListIndex++] = Sq - 7;
							}
							if (EnpassantPos[Side] != -1 && rnk == 3)
							{
								if (fil < 7 && Sq - 7 == EnpassantPos[Side]) List[nListIndex++] = Sq - 7;
								if (fil > 0 && Sq - 9 == EnpassantPos[Side]) List[nListIndex++] = Sq - 9;
							}
							break;
						case ChessConstants.BLACK:
							if (Sq < 56)
							{
								if (BoardColor[Sq + 8] == ChessConstants.NEUTRAL)
								{
									List[nListIndex++] = Sq + 8;
									if (Sq < 16 && BoardColor[Sq + 16] == ChessConstants.NEUTRAL) List[nListIndex++] = Sq + 16;
								}
								if (fil < 7 && BoardColor[Sq + 9] == xSide) List[nListIndex++] = Sq + 9;
								if (fil > 0 && BoardColor[Sq + 7] == xSide) List[nListIndex++] = Sq + 7;
							}
							if (EnpassantPos[Side] != -1 && rnk == 4)
							{
								if (fil > 0 && Sq + 7 == EnpassantPos[Side]) List[nListIndex++] = Sq + 7;
								if (fil < 7 && Sq + 9 == EnpassantPos[Side]) List[nListIndex++] = Sq + 9;
							}
							break;
					}
					break;

				case ChessConstants.KNIGHT:
					if (fil < 7)
					{
						if (rnk > 1 && BoardColor[Sq - 15] != Side) List[nListIndex++] = Sq - 15;
						if (rnk < 6 && BoardColor[Sq + 17] != Side) List[nListIndex++] = Sq + 17;
						if (fil < 6)
						{
							if (rnk > 0 && BoardColor[Sq - 6] != Side) List[nListIndex++] = Sq - 6;
							if (rnk < 7 && BoardColor[Sq + 10] != Side) List[nListIndex++] = Sq + 10;
						}
					}
					if (fil > 0)
					{
						if (rnk > 1 && BoardColor[Sq - 17] != Side) List[nListIndex++] = Sq - 17;
						if (rnk < 6 && BoardColor[Sq + 15] != Side) List[nListIndex++] = Sq + 15;
						if (fil > 1)
						{
							if (rnk > 0 && BoardColor[Sq - 10] != Side) List[nListIndex++] = Sq - 10;
							if (rnk < 7 && BoardColor[Sq + 6] != Side) List[nListIndex++] = Sq + 6;
						}
					}
					break;

				case ChessConstants.BISHOP:

					ii = Sq + 9;
					f = fil;
					r = rnk;
					while (fil < 7 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D1;
						ii += 9;
						fil++;
						rnk++;
					}

				D1:
					ii = Sq + 7;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D2;
						ii += 7;
						fil--;
						rnk++;
					}

				D2:
					ii = Sq - 7;
					fil = f;
					rnk = r;
					while (fil < 7 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D3;
						ii -= 7;
						fil++;
						rnk--;
					}

				D3:
					ii = Sq - 9;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D4;
						ii -= 9;
						fil--;
						rnk--;
					}

				D4:
					break;

				case ChessConstants.ROOK:

					ii = Sq + 1;
					f = fil;
					r = rnk;
					while (fil < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D5;
						ii++;
						fil++;
					}

				D5:
					ii = Sq - 1;
					fil = f;
					while (fil > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D6;
						ii--;
						fil--;
					}

				D6:
					ii = Sq + 8;
					rnk = r;
					while (rnk < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D7;
						ii += 8;
						rnk++;
					}

				D7:
					ii = Sq - 8;
					rnk = r;
					while (rnk > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D8;
						ii -= 8;
						rnk--;
					}

				D8:
					break;

				case ChessConstants.QUEEN:

					ii = Sq + 9;
					f = fil;
					r = rnk;
					while (fil < 7 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D1a;
						ii += 9;
						fil++;
						rnk++;
					}

				D1a:
					ii = Sq + 7;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D2a;
						ii += 7;
						fil--;
						rnk++;
					}

				D2a:
					ii = Sq - 7;
					fil = f;
					rnk = r;
					while (fil < 7 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D3a;
						ii -= 7;
						fil++;
						rnk--;
					}

				D3a:
					ii = Sq - 9;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D4a;
						ii -= 9;
						fil--;
						rnk--;
					}

				D4a:
					ii = Sq + 1;
					fil = f;
					while (fil < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D5a;
						ii++;
						fil++;
					}

				D5a:
					ii = Sq - 1;
					fil = f;
					while (fil > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D6a;
						ii--;
						fil--;
					}

				D6a:
					ii = Sq + 8;
					rnk = r;
					while (rnk < 7 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D7a;
						ii += 8;
						rnk++;
					}

				D7a:
					ii = Sq - 8;
					rnk = r;
					while (rnk > 0 && BoardColor[ii] != Side)
					{
						List[nListIndex++] = ii;
						if (BoardColor[ii] == xSide) goto D8a;
						ii -= 8;
						rnk--;
					}

				D8a:
					break;

				case ChessConstants.KING:

					ii = Sq;

					if (fil < 7)
					{
						if (rnk < 7 && BoardColor[ii + 9] != Side) List[nListIndex++] = ii + 9;
						if (rnk > 0 && BoardColor[ii - 7] != Side) List[nListIndex++] = ii - 7;
						if (BoardColor[ii + 1] != Side) List[nListIndex++] = ii + 1;
					}

					if (fil > 0)
					{
						if (rnk < 7 && BoardColor[ii + 7] != Side) List[nListIndex++] = ii + 7;
						if (rnk > 0 && BoardColor[ii - 9] != Side) List[nListIndex++] = ii - 9;
						if (BoardColor[ii - 1] != Side) List[nListIndex++] = ii - 1;
					}

					if (rnk < 7 && BoardColor[ii + 8] != Side) List[nListIndex++] = ii + 8;
					if (rnk > 0 && BoardColor[ii - 8] != Side) List[nListIndex++] = ii - 8;

					if (!_InCheck(Side))
					{
						if (Side == ChessConstants.WHITE)
						{
							if (_CanCastle(ChessConstants.WHITE, ChessConstants.LEFT)) List[nListIndex++] = 58;
							if (_CanCastle(ChessConstants.WHITE, ChessConstants.RIGHT)) List[nListIndex++] = 62;
						}
						else
						{
							if (_CanCastle(ChessConstants.BLACK, ChessConstants.LEFT)) List[nListIndex++] = 2;
							if (_CanCastle(ChessConstants.BLACK, ChessConstants.RIGHT)) List[nListIndex++] = 6;
						}
					}

					break;
			}

			return (nListIndex);

		}

		/*
			Local function that returns a list of legal moves.
			This list may have moves which put a king into check.
			To remove moves which place a king in check, call RemoveKingInCheck( Count, List );
		*/
		int _LegalMoves1(int Sq, ref int[] List)
		{
			int index, ii;
			int fil, rnk;
			int xSide, Side, f, r;

			if (Sq < 0 || Sq > 63) return (0);

			Side = BoardColor[Sq];
			xSide = Side ^ 1;
			index = 0;
			rnk = Utils.RANK(Sq);
			fil = Utils.FILE(Sq);

			switch (BoardPiece[Sq])
			{

				case ChessConstants.PAWN:
					switch (BoardColor[Sq])
					{
						case ChessConstants.WHITE:
							//					if( Sq >= 8 ){
							if (BoardColor[Sq - 8] == ChessConstants.NEUTRAL) List[index++] = Sq - 8;
							if (fil > 0 && BoardColor[Sq - 9] == xSide) List[index++] = Sq - 9;
							if (fil < 7 && BoardColor[Sq - 7] == xSide) List[index++] = Sq - 7;
							//						}
							if (Sq >= 48 && BoardColor[Sq - 16] == ChessConstants.NEUTRAL && BoardColor[Sq - 8] == ChessConstants.NEUTRAL) List[index++] = Sq - 16;
							if (EnpassantPos[Side] != -1 && rnk == 3)
							{
								if (fil < 7 && Sq - 7 == EnpassantPos[Side]) List[index++] = Sq - 7;
								if (fil > 0 && Sq - 9 == EnpassantPos[Side]) List[index++] = Sq - 9;
							}
							break;
						case ChessConstants.BLACK:
							//					if( Sq  < 56 ){
							if (BoardColor[Sq + 8] == ChessConstants.NEUTRAL) List[index++] = Sq + 8;
							if (fil < 7 && BoardColor[Sq + 9] == xSide) List[index++] = Sq + 9;
							if (fil > 0 && BoardColor[Sq + 7] == xSide) List[index++] = Sq + 7;
							//						}
							if (Sq < 16 && BoardColor[Sq + 16] == ChessConstants.NEUTRAL && BoardColor[Sq + 8] == ChessConstants.NEUTRAL) List[index++] = Sq + 16;
							if (EnpassantPos[Side] != -1 && rnk == 4)
							{
								if (fil > 0 && Sq + 7 == EnpassantPos[Side]) List[index++] = Sq + 7;
								if (fil < 7 && Sq + 9 == EnpassantPos[Side]) List[index++] = Sq + 9;
							}
							break;
					}
					break;

				case ChessConstants.KNIGHT:
					if (fil < 7)
					{
						if (rnk > 1 && BoardColor[Sq - 15] != Side) List[index++] = Sq - 15;
						if (rnk < 6 && BoardColor[Sq + 17] != Side) List[index++] = Sq + 17;
						if (fil < 6)
						{
							if (rnk > 0 && BoardColor[Sq - 6] != Side) List[index++] = Sq - 6;
							if (rnk < 7 && BoardColor[Sq + 10] != Side) List[index++] = Sq + 10;
						}
					}
					if (fil > 0)
					{
						if (rnk > 1 && BoardColor[Sq - 17] != Side) List[index++] = Sq - 17;
						if (rnk < 6 && BoardColor[Sq + 15] != Side) List[index++] = Sq + 15;
						if (fil > 1)
						{
							if (rnk > 0 && BoardColor[Sq - 10] != Side) List[index++] = Sq - 10;
							if (rnk < 7 && BoardColor[Sq + 6] != Side) List[index++] = Sq + 6;
						}
					}
					break;

				case ChessConstants.BISHOP:

					ii = Sq + 9;
					f = fil;
					r = rnk;
					while (fil < 7 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D1;
						ii += 9;
						fil++;
						rnk++;
					}

				D1:
					ii = Sq + 7;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D2;
						ii += 7;
						fil--;
						rnk++;
					}

				D2:
					ii = Sq - 7;
					fil = f;
					rnk = r;
					while (fil < 7 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D3;
						ii -= 7;
						fil++;
						rnk--;
					}

				D3:
					ii = Sq - 9;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D4;
						ii -= 9;
						fil--;
						rnk--;
					}

				D4:
					break;

				case ChessConstants.ROOK:

					ii = Sq + 1;
					f = fil;
					r = rnk;
					while (fil < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D5;
						ii++;
						fil++;
					}

				D5:
					ii = Sq - 1;
					fil = f;
					while (fil > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D6;
						ii--;
						fil--;
					}

				D6:
					ii = Sq + 8;
					rnk = r;
					while (rnk < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D7;
						ii += 8;
						rnk++;
					}

				D7:
					ii = Sq - 8;
					rnk = r;
					while (rnk > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D8;
						ii -= 8;
						rnk--;
					}

				D8:
					break;

				case ChessConstants.QUEEN:

					ii = Sq + 9;
					f = fil;
					r = rnk;
					while (fil < 7 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D1a;
						ii += 9;
						fil++;
						rnk++;
					}

				D1a:
					ii = Sq + 7;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D2a;
						ii += 7;
						fil--;
						rnk++;
					}

				D2a:
					ii = Sq - 7;
					fil = f;
					rnk = r;
					while (fil < 7 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D3a;
						ii -= 7;
						fil++;
						rnk--;
					}

				D3a:
					ii = Sq - 9;
					fil = f;
					rnk = r;
					while (fil > 0 && rnk > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D4a;
						ii -= 9;
						fil--;
						rnk--;
					}

				D4a:
					ii = Sq + 1;
					fil = f;
					while (fil < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D5a;
						ii++;
						fil++;
					}

				D5a:
					ii = Sq - 1;
					fil = f;
					while (fil > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D6a;
						ii--;
						fil--;
					}

				D6a:
					ii = Sq + 8;
					rnk = r;
					while (rnk < 7 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D7a;
						ii += 8;
						rnk++;
					}

				D7a:
					ii = Sq - 8;
					rnk = r;
					while (rnk > 0 && BoardColor[ii] != Side)
					{
						List[index++] = ii;
						if (BoardColor[ii] == xSide) goto D8a;
						ii -= 8;
						rnk--;
					}

				D8a:
					break;

				case ChessConstants.KING:

					ii = Sq;

					if (fil < 7)
					{
						if (rnk < 7 && BoardColor[ii + 9] != Side) List[index++] = ii + 9;
						if (rnk > 0 && BoardColor[ii - 7] != Side) List[index++] = ii - 7;
						if (BoardColor[ii + 1] != Side) List[index++] = ii + 1;
					}

					if (fil > 0)
					{
						if (rnk < 7 && BoardColor[ii + 7] != Side) List[index++] = ii + 7;
						if (rnk > 0 && BoardColor[ii - 9] != Side) List[index++] = ii - 9;
						if (BoardColor[ii - 1] != Side) List[index++] = ii - 1;
					}

					if (rnk < 7 && BoardColor[ii + 8] != Side) List[index++] = ii + 8;
					if (rnk > 0 && BoardColor[ii - 8] != Side) List[index++] = ii - 8;

					break;
			}

			return (index);

		}

		/*
			Remove all moves from list which place the king in check.
		*/
		int _RemoveKingInCheck(int Count, int SrcSq, ref int[] List, int Side)
		{
			int i, dst;
			int NewCount = 0;
			int SrcPc, SrcCl, DestPc, DestCl;
			int enpassante, castle;
			int EnpSq = 0, EnpPc = 0, EnpCl = 0;
			int SrcFile, dstFile;

			for (i = 0; i < Count; i++)
			{

				dst = List[i];

				/*
					Set the enpassante and castle flags to 0. If these are set
					after the move and restore, we'll have to do a little extra
					to restore the enpassante and castle squares.
				*/
				enpassante = castle = 0;

				/*
					Get the source and destination square pieces and colors
					so that we can move and then restore them.
				*/
				SrcPc = BoardPiece[SrcSq];
				SrcCl = BoardColor[SrcSq];
				DestPc = BoardPiece[dst];
				DestCl = BoardColor[dst];

				/*
					Make the move.
				*/
				BoardPiece[SrcSq] = ChessConstants.NONE;
				BoardColor[SrcSq] = ChessConstants.NEUTRAL;
				BoardPiece[dst] = SrcPc;
				BoardColor[dst] = SrcCl;

				SrcFile = Utils.FILE(SrcSq);
				dstFile = Utils.FILE(dst);

				/*
					Handle enpassante move.
				*/
				if (SrcPc == ChessConstants.PAWN && DestPc == 0 && SrcFile != dstFile)
				{
					if (SrcCl == ChessConstants.WHITE)
					{
						if (SrcFile > dstFile) EnpSq = SrcSq - 1;
						else EnpSq = SrcSq + 1;
					}
					else
					{
						if (SrcFile < dstFile) EnpSq = SrcSq - 1;
						else EnpSq = SrcSq + 1;
					}
					EnpPc = BoardPiece[EnpSq];
					EnpCl = BoardColor[EnpSq];
					BoardPiece[EnpSq] = ChessConstants.NONE;
					BoardColor[EnpSq] = ChessConstants.NEUTRAL;
					enpassante = 1;
				}

				/*
					Handle castle move.
				*/
				else if (SrcPc == ChessConstants.KING && (SrcFile == 3 || dstFile == 4) && Math.Abs((SrcFile - dstFile)) > 1)
				{
					if (SrcCl == ChessConstants.WHITE)
					{
						KingSq[ChessConstants.WHITE] = dst;
						if (dstFile > 4)
						{
							BoardPiece[61] = ChessConstants.ROOK;
							BoardColor[61] = ChessConstants.WHITE;
							BoardPiece[63] = ChessConstants.NONE;
							BoardColor[63] = ChessConstants.NEUTRAL;
							castle = 1;
						}
						else
						{
							BoardPiece[59] = ChessConstants.ROOK;
							BoardColor[59] = ChessConstants.WHITE;
							BoardPiece[56] = ChessConstants.NONE;
							BoardColor[56] = ChessConstants.NEUTRAL;
							castle = 2;
						}
					}
					else
					{
						KingSq[ChessConstants.BLACK] = dst;
						if (dstFile > 4)
						{
							BoardPiece[5] = ChessConstants.ROOK;
							BoardColor[5] = ChessConstants.BLACK;
							BoardPiece[7] = ChessConstants.NONE;
							BoardColor[7] = ChessConstants.NEUTRAL;
							castle = 3;
						}
						else
						{
							BoardPiece[3] = ChessConstants.ROOK;
							BoardColor[3] = ChessConstants.BLACK;
							BoardPiece[0] = ChessConstants.NONE;
							BoardColor[0] = ChessConstants.NEUTRAL;
							castle = 4;
						}
					}
				}
				else if (SrcPc == ChessConstants.KING) KingSq[SrcCl] = dst;

				/*
					If we're not in check, record this as a valid move.
				*/
				if (!_InCheck(Side)) List[NewCount++] = dst;

				/*
					Restore the board to its original state.
				*/
				BoardPiece[SrcSq] = SrcPc;
				BoardColor[SrcSq] = SrcCl;
				BoardPiece[dst] = DestPc;
				BoardColor[dst] = DestCl;

				/*
					Handle enpassante restore.
				*/
				if (enpassante != 0)
				{
					BoardPiece[EnpSq] = EnpPc;
					BoardColor[EnpSq] = EnpCl;
				}

				/*
					Handle castle restore.
				*/
				else if (castle != 0)
				{
					switch (castle)
					{
						case 1:
							KingSq[ChessConstants.WHITE] = SrcSq;
							BoardPiece[63] = ChessConstants.ROOK;
							BoardColor[63] = ChessConstants.WHITE;
							BoardPiece[61] = ChessConstants.NONE;
							BoardColor[61] = ChessConstants.NEUTRAL;
							break;
						case 2:
							KingSq[ChessConstants.WHITE] = SrcSq;
							BoardPiece[56] = ChessConstants.ROOK;
							BoardColor[56] = ChessConstants.WHITE;
							BoardPiece[59] = ChessConstants.NONE;
							BoardColor[59] = ChessConstants.NEUTRAL;
							break;
						case 3:
							KingSq[ChessConstants.BLACK] = SrcSq;
							BoardPiece[7] = ChessConstants.ROOK;
							BoardColor[7] = ChessConstants.BLACK;
							BoardPiece[5] = ChessConstants.NONE;
							BoardColor[5] = ChessConstants.NEUTRAL;
							break;
						case 4:
							KingSq[ChessConstants.BLACK] = SrcSq;
							BoardPiece[0] = ChessConstants.ROOK;
							BoardColor[0] = ChessConstants.BLACK;
							BoardPiece[3] = ChessConstants.NONE;
							BoardColor[3] = ChessConstants.NEUTRAL;
							break;
					}
				}
				else if (SrcPc == ChessConstants.KING) KingSq[SrcCl] = SrcSq;

			}

			return (NewCount);

		}

		/*
			TRUE if king is in check.
			FALSE if king is not in check.
		*/
		bool _InCheck(int Side)
		{
			int _KingSq, fil, rnk, xSide, KingFile, KingRank, KingColor, f;
			int Sq, ii;

			xSide = Side ^ 1;
			_KingSq = KingSq[Side];

			KingColor = __sc[_KingSq];
			KingFile = Utils.FILE(_KingSq);
			KingRank = Utils.RANK(_KingSq);

			fil = KingFile;
			ii = _KingSq + 1;
			while (fil < 7 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.ROOK || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq + 1) return (true);
					goto InCheckDone0;
				}
				ii++;
				fil++;
			}

		InCheckDone0:

			fil = KingFile;
			ii = _KingSq - 1;
			while (fil > 0 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.ROOK || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq - 1) return (true);
					goto InCheckDone1;
				}
				ii--;
				fil--;
			}

		InCheckDone1:

			rnk = KingRank;
			ii = _KingSq + 8;
			while (rnk < 7 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.ROOK || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq + 8) return (true);
					goto InCheckDone2;
				}
				ii += 8;
				rnk++;
			}

		InCheckDone2:

			rnk = KingRank;
			ii = _KingSq - 8;
			while (rnk > 0 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.ROOK || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq - 8) return (true);
					goto InCheckDone3;
				}
				ii -= 8;
				rnk--;
			}

		InCheckDone3:

			fil = KingFile;
			rnk = KingRank;
			ii = _KingSq + 9;
			while (fil < 7 && rnk < 7 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.BISHOP || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq + 9) return (true);
					goto InCheckDone4;
				}
				ii += 9;
				fil++;
				rnk++;
			}

		InCheckDone4:

			fil = KingFile;
			rnk = KingRank;
			ii = _KingSq + 7;
			while (fil > 0 && rnk < 7 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.BISHOP || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq + 7) return (true);
					goto InCheckDone5;
				}
				ii += 7;
				fil--;
				rnk++;
			}

		InCheckDone5:

			fil = KingFile;
			rnk = KingRank;
			ii = _KingSq - 9;
			while (fil > 0 && rnk > 0 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.BISHOP || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq - 9) return (true);
					goto InCheckDone6;
				}
				ii -= 9;
				fil--;
				rnk--;
			}

		InCheckDone6:

			fil = KingFile;
			rnk = KingRank;
			ii = _KingSq - 7;
			while (fil < 7 && rnk > 0 && BoardColor[ii] != Side)
			{
				if (BoardColor[ii] == xSide)
				{
					if (BoardPiece[ii] == ChessConstants.BISHOP || BoardPiece[ii] == ChessConstants.QUEEN) return (true);
					if (BoardPiece[ii] == ChessConstants.KING && ii == _KingSq - 7) return (true);
					goto InCheckDone7;
				}
				ii -= 7;
				fil++;
				rnk--;
			}

		InCheckDone7:

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == xSide)
				{
					if (BoardPiece[Sq] == ChessConstants.KNIGHT && __sc[Sq] != KingColor)
					{
						if (distdata[Sq, _KingSq] <= 2)
						{
							f = Utils.FILE(Sq);
							rnk = Utils.RANK(Sq);
							if (f < 7)
							{
								if (rnk > 1 && Sq - 15 == _KingSq && BoardColor[Sq - 15] == Side) return (true);
								if (rnk < 6 && Sq + 17 == _KingSq && BoardColor[Sq + 17] == Side) return (true);
								if (f < 6)
								{
									if (rnk > 0 && Sq - 6 == _KingSq && BoardColor[Sq - 6] == Side) return (true);
									if (rnk < 7 && Sq + 10 == _KingSq && BoardColor[Sq + 10] == Side) return (true);
								}
							}
							if (f > 0)
							{
								if (rnk > 1 && Sq - 17 == _KingSq && BoardColor[Sq - 17] == Side) return (true);
								if (rnk < 6 && Sq + 15 == _KingSq && BoardColor[Sq + 15] == Side) return (true);
								if (f > 1)
								{
									if (rnk > 0 && Sq - 10 == _KingSq && BoardColor[Sq - 10] == Side) return (true);
									if (rnk < 7 && Sq + 6 == _KingSq && BoardColor[Sq + 6] == Side) return (true);
								}
							}
						}
					}
					else if (BoardPiece[Sq] == ChessConstants.PAWN && __sc[Sq] == KingColor)
					{
						fil = Utils.FILE(Sq);
						rnk = Utils.RANK(Sq);
						if (xSide == ChessConstants.BLACK)
						{
							if (fil > 0 && Sq + 7 == _KingSq) return (true);
							if (fil < 7 && Sq + 9 == _KingSq) return (true);
						}
						else
						{
							if (fil > 0 && Sq - 9 == _KingSq) return (true);
							if (fil < 7 && Sq - 7 == _KingSq) return (true);
						}
					}
				}
			}

			return (false);

		}

		/*
			TRUE if king can legally castle.
			FALSE if king cannot legally castle.
		*/
		bool _CanCastle(int Side, int LeftOrRight)
		{
			int xSide;
			int sq, fil, rnk;
			int Count, i;
			int[] List = new int[100];

			if (KingMoves[Side] != 0) return (false);
			if (RookMoves[Side, LeftOrRight] != 0) return (false);

			if (Side == ChessConstants.WHITE)
			{
				if (LeftOrRight == ChessConstants.LEFT)
				{
					if (BoardPiece[57] != 0 || BoardPiece[58] != 0 || BoardPiece[59] != 0 || BoardColor[56] != ChessConstants.WHITE || BoardPiece[56] != ChessConstants.ROOK) return (false);
				}
				else
				{
					if (BoardPiece[61] != 0 || BoardPiece[62] != 0 || BoardColor[63] != ChessConstants.WHITE || BoardPiece[63] != ChessConstants.ROOK) return (false);
				}
			}
			else
			{
				if (LeftOrRight == ChessConstants.RIGHT)
				{
					if (BoardPiece[5] != 0 || BoardPiece[6] != 0 || BoardColor[7] != ChessConstants.BLACK || BoardPiece[7] != ChessConstants.ROOK) return (false);
				}
				else
				{
					if (BoardPiece[1] != 0 || BoardPiece[2] != 0 || BoardPiece[3] != 0 || BoardColor[0] != ChessConstants.BLACK || BoardPiece[0] != ChessConstants.ROOK) return (false);
				}
			}

			xSide = Side ^ 1;

			for (sq = 0; sq < 64; sq++)
			{
				if (BoardColor[sq] == xSide)
				{
					fil = Utils.FILE(sq);
					rnk = Utils.RANK(sq);
					Count = 0;
					switch (BoardPiece[sq])
					{
						case ChessConstants.PAWN:
							if (distdata[KingSq[Side], sq] <= 2) Count = _LegalMoves1(sq, ref List);
							break;
						case ChessConstants.KNIGHT:
							if (distdata[KingSq[Side], sq] <= 2) Count = _LegalMoves1(sq, ref List);
							break;
						case ChessConstants.ROOK:
							if (Side == ChessConstants.WHITE)
							{
								if (rnk == 7) Count = _LegalMoves1(sq, ref List);
								else if (LeftOrRight == ChessConstants.LEFT && (fil == 1 || fil == 2 || fil == 3)) Count = _LegalMoves1(sq, ref List);
								else if (LeftOrRight == ChessConstants.RIGHT && (fil == 5 || fil == 6)) Count = _LegalMoves1(sq, ref List);
							}
							else
							{
								if (rnk == 0) Count = _LegalMoves1(sq, ref List);
								else if (LeftOrRight == ChessConstants.LEFT && (fil == 1 || fil == 2 || fil == 3)) Count = _LegalMoves1(sq, ref List);
								else if (LeftOrRight == ChessConstants.RIGHT && (fil == 5 || fil == 6)) Count = _LegalMoves1(sq, ref List);
							}
							break;
						default:
							Count = _LegalMoves1(sq, ref List);
							break;
					}
					if (Side == ChessConstants.WHITE)
					{
						if (LeftOrRight == ChessConstants.LEFT)
						{
							for (i = 0; i < Count; i++)
							{
								if (List[i] == 56 || List[i] == 57 || List[i] == 58 || List[i] == 59 || List[i] == 60) return (false);
							}
						}
						else
						{
							for (i = 0; i < Count; i++)
							{
								if (List[i] == 60 || List[i] == 61 || List[i] == 62 || List[i] == 63) return (false);
							}
						}
					}
					else
					{
						if (LeftOrRight == ChessConstants.RIGHT)
						{
							for (i = 0; i < Count; i++)
							{
								if (List[i] == 4 || List[i] == 5 || List[i] == 6 || List[i] == 7) return (false);
							}
						}
						else
						{
							for (i = 0; i < Count; i++)
							{
								if (List[i] == 0 || List[i] == 1 || List[i] == 2 || List[i] == 3 || List[i] == 4) return (false);
							}
						}
					}
				}
			}

			return (true);
		}

		/*
			TRUE if king is in checkmate.
			FALSE if king is not in checkmate.
		*/
		bool _InCheckMate(int Side)
		{
			int Sq, Count, i;
			int[] List = new int[100];
			int SrcSq, SrcPc, SrcCl, DestPc, DestCl, DestSq, EnpSq = 0, EnpCl = 0, EnpPc = 0, castle;
			bool Check, enpassante;
			int SrcFile, DestFile;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					Count = _LegalMoves1(Sq, ref List);
					for (i = 0; i < Count; i++)
					{

						SrcSq = Sq;
						DestSq = List[i];

						castle = 0;
						enpassante = false;

						/*
							Get the source and destination square pieces and colors
							so that we can move and then restore them.
						*/
						SrcPc = BoardPiece[SrcSq];
						SrcCl = BoardColor[SrcSq];
						DestPc = BoardPiece[DestSq];
						DestCl = BoardColor[DestSq];

						/*
							Make the move.
						*/
						BoardPiece[SrcSq] = ChessConstants.NONE;
						BoardColor[SrcSq] = ChessConstants.NEUTRAL;
						BoardPiece[DestSq] = SrcPc;
						BoardColor[DestSq] = SrcCl;

						SrcFile = Utils.FILE(SrcSq);
						DestFile = Utils.FILE(DestSq);

						/*
							Handle enpassante move.
						*/
						if (SrcPc == ChessConstants.PAWN && DestPc == 0 && SrcFile != DestFile)
						{
							if (SrcCl == ChessConstants.WHITE)
							{
								if (SrcFile > DestFile) EnpSq = SrcSq + 1;
								else EnpSq = SrcSq - 1;
							}
							else
							{
								if (SrcFile < DestFile) EnpSq = SrcSq + 1;
								else EnpSq = SrcSq - 1;
							}
							enpassante = true;
							EnpPc = SrcPc;
							EnpCl = SrcCl;
							BoardPiece[EnpSq] = ChessConstants.NONE;
							BoardColor[EnpSq] = ChessConstants.NEUTRAL;
						}

						/*
							Handle castle move.
						*/
						else if (SrcPc == ChessConstants.KING && (SrcFile == 3 || SrcFile == 4) && Math.Abs((SrcFile - DestFile)) > 1)
						{
							if (SrcCl == ChessConstants.WHITE)
							{
								KingSq[ChessConstants.WHITE] = DestSq;
								if (DestFile > 4)
								{
									castle = 1;
									BoardPiece[61] = ChessConstants.ROOK;
									BoardColor[61] = ChessConstants.WHITE;
									BoardPiece[63] = ChessConstants.NONE;
									BoardColor[63] = ChessConstants.NEUTRAL;
								}
								else
								{
									castle = 2;
									BoardPiece[59] = ChessConstants.ROOK;
									BoardColor[59] = ChessConstants.WHITE;
									BoardPiece[56] = ChessConstants.NONE;
									BoardColor[56] = ChessConstants.NEUTRAL;
								}
							}
							else
							{
								KingSq[ChessConstants.BLACK] = DestSq;
								if (DestFile > 4)
								{
									castle = 3;
									BoardPiece[5] = ChessConstants.ROOK;
									BoardColor[5] = ChessConstants.BLACK;
									BoardPiece[7] = ChessConstants.NONE;
									BoardColor[7] = ChessConstants.NEUTRAL;
								}
								else
								{
									castle = 4;
									BoardPiece[3] = ChessConstants.ROOK;
									BoardColor[3] = ChessConstants.BLACK;
									BoardPiece[0] = ChessConstants.NONE;
									BoardColor[0] = ChessConstants.NEUTRAL;
								}
							}
						}
						else if (SrcPc == ChessConstants.KING) KingSq[SrcCl] = DestSq;

						Check = _InCheck(Side);

						/*
							Restore the board to its original state.
						*/
						BoardPiece[SrcSq] = SrcPc;
						BoardColor[SrcSq] = SrcCl;
						BoardPiece[DestSq] = DestPc;
						BoardColor[DestSq] = DestCl;

						/*
							Handle enpassante restore.
						*/
						if (enpassante)
						{
							BoardPiece[EnpSq] = EnpPc;
							BoardColor[EnpSq] = EnpCl;
						}

						/*
							Handle castle restore.
						*/
						else if (castle != 0)
						{
							switch (castle)
							{
								case 1:
									KingSq[ChessConstants.WHITE] = SrcSq;
									BoardPiece[63] = ChessConstants.ROOK;
									BoardColor[63] = ChessConstants.WHITE;
									BoardPiece[61] = ChessConstants.NONE;
									BoardColor[61] = ChessConstants.NEUTRAL;
									break;
								case 2:
									KingSq[ChessConstants.WHITE] = SrcSq;
									BoardPiece[56] = ChessConstants.ROOK;
									BoardColor[56] = ChessConstants.WHITE;
									BoardPiece[59] = ChessConstants.NONE;
									BoardColor[59] = ChessConstants.NEUTRAL;
									break;
								case 3:
									KingSq[ChessConstants.BLACK] = SrcSq;
									BoardPiece[7] = ChessConstants.ROOK;
									BoardColor[7] = ChessConstants.BLACK;
									BoardPiece[5] = ChessConstants.NONE;
									BoardColor[5] = ChessConstants.NEUTRAL;
									break;
								case 4:
									KingSq[ChessConstants.BLACK] = SrcSq;
									BoardPiece[0] = ChessConstants.ROOK;
									BoardColor[0] = ChessConstants.BLACK;
									BoardPiece[3] = ChessConstants.NONE;
									BoardColor[3] = ChessConstants.NEUTRAL;
									break;
							}
						}
						else if (SrcPc == ChessConstants.KING) KingSq[SrcCl] = SrcSq;

						if (!Check) return (false);
					}
				}
			}

			return (true);

		}

		/**************************************************************************
		***************************************************************************
		**                                                                       **
		**                                                                       **
		**                    Evaluation Routines Begin Here                     **
		**                                                                       **
		**                                                                       **
		***************************************************************************
		**************************************************************************/

		public int MaterialAdvantage( int Side )
		{
			int xSide;
			int[] Material = new int[2];

			xSide = Side ^ 1;
			Material[ChessConstants.WHITE] = Material[ChessConstants.BLACK] = 0;

			for (int i = 0; i < 64; i++)
			{
				if (BoardColor[i] != ChessConstants.NEUTRAL)
				{
					int Color = BoardColor[i];
					int Piece = BoardPiece[i];
					Material[Color] += Materials[Piece];
				}
			}

			return (Material[Side] - Material[xSide]);
		}

		public int _ScorePosition(int Side)
		{
			int[] Score = new int[2];
			int Sq;
			int Color, Piece;
			int ReturnScore;
			int xSide;
			int winner, loser;
			int i;
			int[] Bishops = new int[2];
			int count;

			xSide = Side ^ 1;

			Material[ChessConstants.WHITE] = Material[ChessConstants.BLACK] = 0;
			Bishops[ChessConstants.WHITE] = Bishops[ChessConstants.BLACK] = 0;
			for (i = 0; i < 8; i++) PawnsOnFile[ChessConstants.WHITE, i] = PawnsOnFile[ChessConstants.BLACK, i] = 0;
			Pawns[ChessConstants.WHITE] = Pawns[ChessConstants.BLACK] = 0;

			for (i = 0; i < 64; i++)
			{
				if (BoardColor[i] != ChessConstants.NEUTRAL)
				{
					Color = BoardColor[i];
					Piece = BoardPiece[i];
					Material[Color] += Materials[Piece];
					if (Piece == ChessConstants.BISHOP) Bishops[Color]++;
					else if (Piece == ChessConstants.PAWN)
					{
						PawnsOnFile[Color, i & 7]++;
						Pawns[Color]++;
					}
				}
			}


			if (
				// Opponent has no material   and       You have no pawns   or    all of your material is in pawns
				(Material[xSide] == 0 && (Pawns[Side] == 0 || Material[Side] == Pawns[Side] * 100))

				// or
				||

				// You have no material       and       Opponent has no pawns  or    all opponent material is in pawns
				(Material[Side] == 0 && (Pawns[xSide] == 0 || Material[xSide] == Pawns[xSide] * 100)))
			{

				// Here we will declare winner and loser.
				if (Material[ChessConstants.WHITE] > Material[ChessConstants.BLACK])
				{
					winner = ChessConstants.WHITE;
					loser = ChessConstants.BLACK;
				}
				else
				{
					winner = ChessConstants.BLACK;
					loser = ChessConstants.WHITE;
				}

				if (Pawns[winner] != 0)
				{
					Score[winner] = _ScoreKPK(Side, winner);
				}
				else if (Material[winner] == 600)
				{
					Score[winner] = _ScoreKBNK(Side, winner);
				}
				else if (Material[winner] > 300)
				{
					Score[winner] = Material[winner] - ChessData.DyingKing[KingSq[loser]] - 2 * distdata[KingSq[winner], KingSq[loser]];
				}

				if (Side == winner) return (Score[winner]);

				return (-Score[winner]);
			}

			Develop[ChessConstants.BLACK] = Develop[ChessConstants.WHITE] = 0;

			// Both sides have plenty of material.
			if (Material[ChessConstants.BLACK] > 3000 && Material[ChessConstants.WHITE] > 3000)
			{
				// Award bonus for having moved knights and bishops.

				// Black
				if (BoardPiece[1] != ChessConstants.KNIGHT) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[2] != ChessConstants.BISHOP) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[5] != ChessConstants.BISHOP) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[6] != ChessConstants.KNIGHT) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;

				// White
				if (BoardPiece[57] != ChessConstants.KNIGHT) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[58] != ChessConstants.BISHOP) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[61] != ChessConstants.BISHOP) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[62] != ChessConstants.KNIGHT) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
			}

			// We start off our score with our development bonus.
			Score[ChessConstants.BLACK] = Develop[ChessConstants.BLACK];
			Score[ChessConstants.WHITE] = Develop[ChessConstants.WHITE];

			// Record king row and column.
			KingRow[ChessConstants.WHITE] = KingSq[ChessConstants.WHITE] >> 3;
			KingRow[ChessConstants.BLACK] = KingSq[ChessConstants.BLACK] >> 3;
			KingCol[ChessConstants.WHITE] = KingSq[ChessConstants.WHITE] & 7;
			KingCol[ChessConstants.BLACK] = KingSq[ChessConstants.BLACK] & 7;

			// Look for open files.
			OpenFiles[ChessConstants.WHITE] = _OpenAndHalfOpenFiles(ChessConstants.WHITE);
			OpenFiles[ChessConstants.BLACK] = _OpenAndHalfOpenFiles(ChessConstants.BLACK);

			// If we still have all of our pawns we get a bonus.
			if (Pawns[ChessConstants.BLACK] == 8) Score[ChessConstants.BLACK] += ChessConstants.EIGHTPAWNBONUS;
			if (Pawns[ChessConstants.WHITE] == 8) Score[ChessConstants.WHITE] += ChessConstants.EIGHTPAWNBONUS;

			// If we still have our bishops we get a bonus.
			if (Bishops[ChessConstants.WHITE] == 2) Score[ChessConstants.WHITE] += ChessConstants.TWOBISHOPBONUS;
			if (Bishops[ChessConstants.BLACK] == 2) Score[ChessConstants.BLACK] += ChessConstants.TWOBISHOPBONUS;

			// White pawn control of center.
			count = 0;
			if ((BoardColor[43] == ChessConstants.WHITE && BoardPiece[43] == ChessConstants.PAWN) || (BoardColor[35] == ChessConstants.WHITE && BoardPiece[35] == ChessConstants.PAWN)) count++;
			if ((BoardColor[44] == ChessConstants.WHITE && BoardPiece[44] == ChessConstants.PAWN) || (BoardColor[36] == ChessConstants.WHITE && BoardPiece[36] == ChessConstants.PAWN)) count++;
			Score[ChessConstants.WHITE] += cpb[count];

			// Black pawn control of center.
			count = 0;
			if ((BoardColor[19] == ChessConstants.BLACK && BoardPiece[19] == ChessConstants.PAWN) || (BoardColor[27] == ChessConstants.BLACK && BoardPiece[27] == ChessConstants.PAWN)) count++;
			if ((BoardColor[20] == ChessConstants.BLACK && BoardPiece[20] == ChessConstants.PAWN) || (BoardColor[28] == ChessConstants.BLACK && BoardPiece[28] == ChessConstants.PAWN)) count++;
			Score[ChessConstants.BLACK] += cpb[count];

			for (Sq = 0; Sq < 64; Sq++)
			{
				Color = BoardColor[Sq];
				if (Color != ChessConstants.NEUTRAL)
				{
					switch (BoardPiece[Sq])
					{
						case ChessConstants.PAWN:
							Score[Color] += _PawnScore(Sq, Color);
							break;
						case ChessConstants.KNIGHT:
							Score[Color] += _KnightScore(Sq, Color);
							break;
						case ChessConstants.BISHOP:
							Score[Color] += _BishopScore(Sq, Color);
							break;
						case ChessConstants.ROOK:
							Score[Color] += _RookScore(Sq, Color);
							break;
						case ChessConstants.QUEEN:
							Score[Color] += _QueenScore(Sq, Color);
							break;
						case ChessConstants.KING:
							Score[Color] += _KingScore(Sq, Color);
							break;
					}
				}
			}

			ReturnScore = ( Material[Side] - Material[Side ^ 1] ) + ( Score[Side] - Score[Side ^ 1] );

			return (ReturnScore);
		}

#if CRAP
		public int _ScorePosition(int Side)
		{
			int[] Score = new int[2];
			int Sq;
			int Color, Piece;
			int ReturnScore;
			int xSide;
			int winner, loser;
			int i;
			int[] Bishops = new int[2];
			int count;

			xSide = Side ^ 1;

			Material[ChessConstants.WHITE] = Material[ChessConstants.BLACK] = 0;
			Bishops[ChessConstants.WHITE] = Bishops[ChessConstants.BLACK] = 0;
			for (i = 0; i < 8; i++) PawnsOnFile[ChessConstants.WHITE, i] = PawnsOnFile[ChessConstants.BLACK, i] = 0;
			Pawns[ChessConstants.WHITE] = Pawns[ChessConstants.BLACK] = 0;

			for (i = 0; i < 64; i++)
			{
				if (BoardColor[i] != ChessConstants.NEUTRAL)
				{
					Color = BoardColor[i];
					Piece = BoardPiece[i];
					Material[Color] += Materials[Piece];
					if (Piece == ChessConstants.BISHOP) Bishops[Color]++;
					else if (Piece == ChessConstants.PAWN)
					{
						PawnsOnFile[Color, i & 7]++;
						Pawns[Color]++;
					}
				}
			}


			if (
				// Opponent has no material   and       You have no pawns   or    all of your material is in pawns
				(  Material[xSide] == 0       &&      ( Pawns[Side] == 0    ||    Material[Side] == Pawns[Side] * 100 ) )

				// or
				|| 
				
				// You have no material       and       Opponent has no pawns  or    all opponent material is in pawns
				(Material[Side] == 0          &&      ( Pawns[xSide] == 0      ||    Material[xSide] == Pawns[xSide] * 100)))
			{

				// Here we will declare winner and loser.
				if (Material[ChessConstants.WHITE] > Material[ChessConstants.BLACK])
				{
					winner = ChessConstants.WHITE;
					loser = ChessConstants.BLACK;
				}
				else
				{
					winner = ChessConstants.BLACK;
					loser = ChessConstants.WHITE;
				}

				if (Pawns[winner] != 0)
				{
					Score[winner] = _ScoreKPK(Side, winner);
				}
				else if (Material[winner] == 600)
				{
					Score[winner] = _ScoreKBNK(Side, winner);
				}
				else if (Material[winner] > 300)
				{
					Score[winner] = Material[winner] - ChessData.DyingKing[KingSq[loser]] - 2 * distdata[KingSq[winner], KingSq[loser]];
				}

				if (Side == winner) return (Score[winner]);

				return (-Score[winner]);
			}

			Develop[ChessConstants.BLACK] = Develop[ChessConstants.WHITE] = 0;

			// Both sides have plenty of material.
			if (Material[ChessConstants.BLACK] > 3000 && Material[ChessConstants.WHITE] > 3000)
			{
				// Award bonus for having moved knights and bishops.

				// Black
				if (BoardPiece[1] != ChessConstants.KNIGHT) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[2] != ChessConstants.BISHOP) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[5] != ChessConstants.BISHOP) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[6] != ChessConstants.KNIGHT) Develop[ChessConstants.BLACK] += ChessConstants.DEVELOPBONUS;

				// White
				if (BoardPiece[57] != ChessConstants.KNIGHT) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[58] != ChessConstants.BISHOP) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[61] != ChessConstants.BISHOP) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
				if (BoardPiece[62] != ChessConstants.KNIGHT) Develop[ChessConstants.WHITE] += ChessConstants.DEVELOPBONUS;
			}

			// We start off our score with our development bonus.
			Score[ChessConstants.BLACK] = Develop[ChessConstants.BLACK];
			Score[ChessConstants.WHITE] = Develop[ChessConstants.WHITE];

			// Record king row and column.
			KingRow[ChessConstants.WHITE] = KingSq[ChessConstants.WHITE] >> 3;
			KingRow[ChessConstants.BLACK] = KingSq[ChessConstants.BLACK] >> 3;
			KingCol[ChessConstants.WHITE] = KingSq[ChessConstants.WHITE] & 7;
			KingCol[ChessConstants.BLACK] = KingSq[ChessConstants.BLACK] & 7;

			// Look for open files.
			OpenFiles[ChessConstants.WHITE] = _OpenAndHalfOpenFiles(ChessConstants.WHITE);
			OpenFiles[ChessConstants.BLACK] = _OpenAndHalfOpenFiles(ChessConstants.BLACK);

			// If we still have all of our pawns we get a bonus.
			if (Pawns[ChessConstants.BLACK] == 8) Score[ChessConstants.BLACK] += ChessConstants.EIGHTPAWNBONUS;
			if (Pawns[ChessConstants.WHITE] == 8) Score[ChessConstants.WHITE] += ChessConstants.EIGHTPAWNBONUS;

			// If we still have our bishops we get a bonus.
			if (Bishops[ChessConstants.WHITE] == 2) Score[ChessConstants.WHITE] += ChessConstants.TWOBISHOPBONUS;
			if (Bishops[ChessConstants.BLACK] == 2) Score[ChessConstants.BLACK] += ChessConstants.TWOBISHOPBONUS;

			// White pawn control of center.
			count = 0;
			if ((BoardColor[43] == ChessConstants.WHITE && BoardPiece[43] == ChessConstants.PAWN) || (BoardColor[35] == ChessConstants.WHITE && BoardPiece[35] == ChessConstants.PAWN)) count++;
			if ((BoardColor[44] == ChessConstants.WHITE && BoardPiece[44] == ChessConstants.PAWN) || (BoardColor[36] == ChessConstants.WHITE && BoardPiece[36] == ChessConstants.PAWN)) count++;
			Score[ChessConstants.WHITE] += cpb[count];

			// Black pawn control of center.
			count = 0;
			if ((BoardColor[19] == ChessConstants.BLACK && BoardPiece[19] == ChessConstants.PAWN) || (BoardColor[27] == ChessConstants.BLACK && BoardPiece[27] == ChessConstants.PAWN)) count++;
			if ((BoardColor[20] == ChessConstants.BLACK && BoardPiece[20] == ChessConstants.PAWN) || (BoardColor[28] == ChessConstants.BLACK && BoardPiece[28] == ChessConstants.PAWN)) count++;
			Score[ChessConstants.BLACK] += cpb[count];

			for (Sq = 0; Sq < 64; Sq++)
			{
				Color = BoardColor[Sq];
				if (Color != ChessConstants.NEUTRAL)
				{//RICK
					switch (BoardPiece[Sq])
					{
						case ChessConstants.PAWN:
							Score[Color] += _PawnScore(Sq, Color);
							break;
						case ChessConstants.KNIGHT:
							Score[Color] += _KnightScore(Sq, Color);
							break;
						case ChessConstants.BISHOP:
							Score[Color] += _BishopScore(Sq, Color);
							break;
						case ChessConstants.ROOK:
							Score[Color] += _RookScore(Sq, Color);
							break;
						case ChessConstants.QUEEN:
							Score[Color] += _QueenScore(Sq, Color);
							break;
						case ChessConstants.KING:
							Score[Color] += _KingScore(Sq, Color);
							break;
					}
				}
			}

			ReturnScore = Material[Side] - Material[Side ^ 1] + Score[Side] - Score[Side ^ 1];

			return (ReturnScore);
		}
#endif

		int _ScoreKPK(int Side, int winner)
		{
			int Sq, r;
			int _Sq;
			int score = 0;
			int count = 0;
			int loser;
			int rank;

			loser = winner ^ 1;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					rank = Utils.RANK(Sq);
					_Sq = Sq;
					score += 50;
					if (count != 0) score += 70;
					if (winner == ChessConstants.WHITE)
					{
						if (Side == loser) r = rank + 1;
						else r = rank;
						if (Utils.RANK(KingSq[loser]) <= r && distdata[Sq, KingSq[loser]] < r + 1) score += (10 * (7 - rank));
						else score = 500 + 50 * (7 - rank);
						if (rank > 1) _Sq -= 16;
						else if (rank == 1) _Sq -= 8;
					}
					else
					{
						if (Side == loser) r = rank - 1;
						else r = rank;
						if (Utils.RANK(KingSq[loser]) >= r && distdata[Sq, KingSq[loser]] < 8 - r) score += (10 * rank);
						else score = 500 + 50 * rank;
						if (rank < 6) _Sq += 16;
						else if (rank == 6) _Sq += 8;
					}
					count++;
					score += (8 * (taxidata[KingSq[loser], _Sq] - taxidata[KingSq[winner], _Sq]));
				}
			}

			return (score);

		}

		int _ScoreKBNK(int Side, int winner)
		{
			int score = 0, KBNKsq = 0;
			int Sq;
			int loser;

			loser = winner ^ 1;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardPiece[Sq] == ChessConstants.BISHOP)
				{
					if ((Utils.RANK(Sq) & 1) == (Utils.FILE(Sq) & 1)) KBNKsq = 0;
					else KBNKsq = 7;
				}
			}

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					score += Material[winner] - 300;
					if (KBNKsq == 0) score += ChessData.KBNK[KingSq[loser]];
					else score += ChessData.KBNK[locn(Utils.RANK(KingSq[loser]), 7 - Utils.FILE(KingSq[loser]))];
					score -= taxidata[KingSq[winner], KingSq[loser]];
				}
			}

			return (score);

		}

		static int[] PB =
		{
			 0,  0,  0,  0,  0,  0,  0,  0,
			-1, -1, -1, -3, -3, -1, -1, -1,
			 0,  0,  0,  2,  2,  1,  0,  0,
			 0,  0,  2,  3,  3,  2,  0,  0,
			 2,  0,  3,  4,  4,  3,  0,  2,
			 3,  0,  4,  6,  6,  4,  0,  3,
			 5,  0,  6,  8,  8,  6,  0,  5,
			 100,100,100,100,100,100,100,100
		};

		int _PawnScore(int Sq, int Side)
		{
			int Score = 0;
			int col, row, i, xSide;

			col = Sq & 7;
			row = Sq / 8;
			xSide = Side ^ 1;

			if (Side == 0) row = 7 - row;
			return (PB[row*8+col]);

			/*
				Award a bonus for pawn advancement.
			*/
			if (Side != 0) Score += ChessData.PawnAdvance[Sq];
			else Score += ChessData.PawnAdvance[(7 - (Sq >> 3)) * 8 + col];

			/*
				Award a bonus for isolated pawns.
			*/
			if (col == 0)
			{
				if (PawnsOnFile[Side, 1] == 0)
				{
					Score += ChessConstants.ISOLATEDPAWN0;
					switch (Side)
					{
						case ChessConstants.WHITE:
							for (i = Sq - 8; i > 8; i -= 8)
							{
								if (BoardPiece[i] == ChessConstants.PAWN && BoardColor[i] == xSide)
								{
									Score += ChessConstants.ISOLATEDPAWN1;
									break;
								}
							}
							break;
						case ChessConstants.BLACK:
							for (i = Sq + 8; i < 64 - 8; i += 8)
							{
								if (BoardPiece[i] == ChessConstants.PAWN && BoardColor[i] == xSide)
								{
									Score += ChessConstants.ISOLATEDPAWN1;
									break;
								}
							}
							break;
					}
				}
			}
			else if (col == 7)
			{
				if (PawnsOnFile[Side, 6] == 0)
				{
					Score += ChessConstants.ISOLATEDPAWN0;
					switch (Side)
					{
						case ChessConstants.WHITE:
							for (i = Sq - 8; i > 8; i -= 8)
							{
								if (BoardPiece[i] == ChessConstants.PAWN && BoardColor[i] == xSide)
								{
									Score += ChessConstants.ISOLATEDPAWN1;
									break;
								}
							}
							break;
						case ChessConstants.BLACK:
							for (i = Sq + 8; i < 64 - 8; i += 8)
							{
								if (BoardPiece[i] == ChessConstants.PAWN && BoardColor[i] == xSide)
								{
									Score += ChessConstants.ISOLATEDPAWN1;
									break;
								}
							}
							break;
					}
				}
			}
			else
			{
				if (PawnsOnFile[Side, col - 1] == 0 && PawnsOnFile[Side, col + 1] == 0)
				{
					Score += ChessConstants.ISOLATEDPAWN0;
					switch (Side)
					{
						case ChessConstants.WHITE:
							for (i = Sq - 8; i > 8; i -= 8)
							{
								if (BoardPiece[i] == ChessConstants.PAWN && BoardColor[i] == xSide)
								{
									Score += ChessConstants.ISOLATEDPAWN1;
									break;
								}
							}
							break;
						case ChessConstants.BLACK:
							for (i = Sq + 8; i < 64 - 8; i += 8)
							{
								if (BoardPiece[i] == ChessConstants.PAWN && BoardColor[i] == xSide)
								{
									Score += ChessConstants.ISOLATEDPAWN1;
									break;
								}
							}
							break;
					}
				}
			}

			/*
				Award a bonus for pawn rams.
			*/
			if (Side == ChessConstants.WHITE)
			{
				for (i = Sq - 8; i > 16; i -= 8)
				{
					if (BoardPiece[i] == ChessConstants.PAWN && BoardPiece[i - 8] == ChessConstants.PAWN && BoardColor[i] != BoardColor[i - 8])
					{
						Score += ChessConstants.PAWNRAMBONUS;
						i = 0;
					}
				}
			}
			else
			{
				for (i = Sq + 8; i < 48; i += 8)
				{
					if (BoardPiece[i] == ChessConstants.PAWN && BoardPiece[i + 8] == ChessConstants.PAWN && BoardColor[i] != BoardColor[i + 8])
					{
						Score += ChessConstants.PAWNRAMBONUS;
						i = 48;
					}
				}
			}

			return (Score);

		}

		int _KnightScore(int Sq, int Side)
		{
			int Score = 0;
			int row, col;

			//return( 0 );

			/*
				Get the row and column for later use.
			*/
			row = Sq >> 3;
			col = Sq & 7;

			/*
				Add a positional bonus from a precalculated table.
			*/
			Score += ChessData.KnightPositionBonus[Sq];

			/*
				Add a positive or negative value based ont
				the distance from both kings.
			*/
			Score += ((8 - distdata[Sq, KingSq[ChessConstants.WHITE]]) * ChessConstants.KNIGHTDISTANCE0);
			Score += ((8 - distdata[Sq, KingSq[ChessConstants.BLACK]]) * ChessConstants.KNIGHTDISTANCE0);

			/*
				Add a bonus for an outpost knight.
			*/
			if (col != 0 && col != 7)
			{	/* Can't be an outpost knight if on edge. */
				Score += ChessConstants.OUTPOSTKNIGHTBONUS0;
				if ((row <= 4 && Side == ChessConstants.WHITE) || (row >= 3 && Side == ChessConstants.BLACK))
				{ /* Outpost knights are on opponents side. */
					switch (Side)
					{
						case ChessConstants.WHITE:
							if (Sq >= 8 && BoardPiece[Sq - 7] != ChessConstants.PAWN && BoardPiece[Sq - 9] != ChessConstants.PAWN) Score += ChessConstants.OUTPOSTKNIGHTBONUS1;
							break;
						case ChessConstants.BLACK:
							if (Sq < 56 && BoardPiece[Sq + 7] != ChessConstants.PAWN && BoardPiece[Sq + 9] != ChessConstants.PAWN) Score += ChessConstants.OUTPOSTKNIGHTBONUS1;
							break;
					}
				}
			}

			return (Score);

		}

		int _BishopScore(int Sq, int Side)
		{
			int Score = 0;
			int pawncount = 0;
			int mobility = 0;
			int row, col, dest, r, c;

			int nBCIndex = 0, nBPIndex = 0;

			/*
				Add a positional bonus from a precalculated table.
			*/
			Score += ChessData.BishopPositionBonus[Sq];

			/*
				Award a bonus for good/bad bishops.
			*/
			if (__sc[Sq] == 0)
			{
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;

			}
			else
			{
				nBPIndex++;
				nBCIndex++;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 3;
				nBCIndex += 3;

				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex++;
				nBCIndex++;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;
				nBPIndex += 2;
				nBCIndex += 2;
				if (BoardPiece[nBPIndex] == ChessConstants.PAWN && BoardColor[nBCIndex] == Side) pawncount++;

			}

			Score += s[pawncount];
			nBPIndex = 0;
			r = (Sq >> 3);
			c = (Sq & 7);

			/*
				Award a bonus for mobility.
			*/
			row = r; // ( Sq >> 3 ) + 1;
			col = c; // ( Sq & 7 ) + 1;
			dest = Sq + 9;
			//	while( row < 8 && col < 8 && !BP[dest] ){
			while (row < 7 && col < 7 && BoardPiece[dest] == 0)
			{
				mobility++;
				row++;
				col++;
				dest += 9;
			}

			row = r; // ( Sq >> 3 ) + 1;
			col = c; // ( Sq & 7 ) - 1;
			dest = Sq + 7;
			//	while( row < 8 && col >= 0 && !BP[dest] ){
			while (row < 7 && col >= 1 && BoardPiece[dest] == 0)
			{
				mobility++;
				row++;
				col--;
				dest += 7;
			}

			row = r; // ( Sq >> 3 ) - 1;
			col = c; // ( Sq & 7 ) + 1;
			dest = Sq - 7;
			//	while( row >= 0 && col < 8 && !BP[dest] ){
			while (row >= 1 && col < 7 && BoardPiece[dest] == 0)
			{
				mobility++;
				row--;
				col++;
				dest -= 7;
			}

			row = r; // ( Sq >> 3 ) - 1;
			col = c; // ( Sq & 7 ) - 1;
			dest = Sq - 9;
			//	while( row >= 0 && col >= 0 && !BP[dest] ){
			while (row >= 1 && col >= 1 && BoardPiece[dest] == 0)
			{
				mobility++;
				row--;
				col--;
				dest -= 9;
			}

			Score += (mobility * ChessConstants.BISHOPSCAN0); // ( ( BISHOPSCAN0 - mobility ) * BISHOPSCAN1 );

			/*
				Penalize for not developing.
			*/

			return (Score);

		}

		int _RookScore(int Sq, int Side)
		{
			int Score = 0;
			int i, col, row;
			int max, dest, mobility = 0;

			/*
				Add a positive or negative value based ont
				the distance from opponent's kings.
			*/
			Score += (ChessConstants.ROOKDISTANCE0 * distdata[Sq, KingSq[Side ^ 1]]);

			/*
				Award a bonus for opened and half-opened files.
			*/
			Score += OpenFiles[Side];

			/*
				Award a bonus for rooks on the seventh rank.
			*/
			if (Side == 0) i = 56;
			else i = 0;
			max = i + 8;

			for (col = i; col < max; col++)
			{
				if (BoardPiece[col] == ChessConstants.ROOK && BoardPiece[col] == Side) Score += ChessConstants.ROOKSEVENTHBONUS;
			}

			/*
				Award a bonus for mobility.
			*/
			row = (Sq >> 3) + 1;
			dest = Sq + 8;
			while (row < 8 && BoardPiece[dest] == 0)
			{
				mobility++;
				row++;
				dest += 8;
			}

			row = (Sq >> 3) - 1;
			dest = Sq - 8;
			while (row >= 0 && BoardPiece[dest] == 0)
			{
				mobility++;
				row--;
				dest -= 8;
			}

			col = (Sq & 7) + 1;
			dest = Sq + 1;
			while (col < 8 && BoardPiece[dest] == 0)
			{
				mobility++;
				col++;
				dest++;
			}

			col = (Sq & 7) - 1;
			dest = Sq - 1;
			while (col >= 0 && BoardPiece[dest] == 0)
			{
				mobility++;
				col--;
				dest--;
			}

			Score += (mobility * ChessConstants.ROOKSCAN0);

			/*
				Award a pre-castle bonus if this is the original position.
			*/
			//	if( KingMoves[Side] >= 1000 ) Score += 40;
			//	else{
			if (RookPos[Side, 0] == Sq)
			{
				if (KingMoves[Side] == 0)
				{
					if (RookMoves[Side, 0] != 0) Score += ChessConstants.PRECASTLEROOKPENALTY;
					else Score += ChessConstants.PRECASTLEROOKBONUS;
				}
			}
			else
			{
				if (KingMoves[Side] == 0)
				{
					if (RookMoves[Side, 1] != 0) Score += ChessConstants.PRECASTLEROOKPENALTY;
					else Score += ChessConstants.PRECASTLEROOKBONUS;
				}
			}
			//		}

			return (Score);

		}

		int _OpenAndHalfOpenFiles(int Side)
		{
			int Sq, i, ii;
			int opened = 0, halfopened = 0;
			int count, fil, rnk;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardPiece[Sq] == ChessConstants.ROOK && BoardColor[Sq] == Side)
				{

					fil = Utils.FILE(Sq);
					rnk = Utils.RANK(Sq);

					ii = rnk * 8;
					count = 0;
					for (i = 0; i < 8; i++)
					{
						if (BoardColor[ii] == ChessConstants.NEUTRAL) count++;
						ii++;
					}
					if (count == 7) opened++;
					else if (count == 6) halfopened++;

					ii = fil;
					count = 0;
					for (i = 0; i < 8; i++)
					{
						if (BoardColor[ii] == ChessConstants.NEUTRAL) count++;
						ii += 8;
					}
					if (count == 7) opened++;
					else if (count == 6) halfopened++;

				}
			}

			return (opened * ChessConstants.ROOKHALF0 + halfopened * ChessConstants.ROOKHALF1);

		}

		int _QueenScore(int Sq, int Side)
		{
			int Score = 0;
			int row, col;

			//return( 0 );

			row = Utils.RANK(Sq);
			col = Utils.FILE(Sq);

			/*
				Adjust the score according to centralization.
			*/
			//	Score = cent[row];
			//	Score += cent[col];

			/*
				Add a positive or negative value based ont
				the distance from opponent's kings.
			*/
			//	Score += ( distance( Sq, KingSq[Side^1] * QUEENDISTANCE0 ) );
			Score += ((7 - distdata[Sq, KingSq[Side ^ 1]] * ChessConstants.QUEENDISTANCE0));

			Score += _ExposedKingQueenValue(Side);

			if (Side == ChessConstants.WHITE)
			{
				if (Develop[ChessConstants.WHITE] < ChessConstants.DEVELOPBONUS * 3 && Material[ChessConstants.WHITE] > 3000 && BoardPiece[59] != ChessConstants.QUEEN) Score += ChessConstants.QUEENEARLYMOVE;
			}
			else
			{
				if (Develop[ChessConstants.BLACK] < ChessConstants.DEVELOPBONUS * 3 && Material[ChessConstants.BLACK] > 3000 && BoardPiece[3] != ChessConstants.QUEEN) Score += ChessConstants.QUEENEARLYMOVE;
			}

			return (Score);

		}

		static int[] rpos = { 1, 1, 0, -1, -1, -1, 0, 1 };
		static int[] cpos = { 0, 1, 1, 1, 0, -1, -1, -1 };
		static int[] adds = { 8, 9, 1, -7, -8, -9, -1, 7 };

		int _ExposedKingQueenValue(int Side)
		{
			int Score;
			int exposed = 0;
			int row, col, Sq;

			Sq = KingSq[Side];
			row = Utils.RANK(Sq);
			col = Utils.FILE(Sq);
			//			if( row > 0 ){
			//				if( col > 0 ){
			if (Sq - 9 >= 0 && BoardColor[Sq - 9] == ChessConstants.NEUTRAL) exposed++;
			//					}
			//				if( col < 7 ){
			if (Sq - 7 >= 0 && BoardColor[Sq - 7] == ChessConstants.NEUTRAL) exposed++;
			//					}
			if (Sq - 8 >= 0 && BoardColor[Sq - 8] == ChessConstants.NEUTRAL) exposed++;
			//				}
			//			if( row < 7 ){
			//				if( col > 0 ){
			if (Sq + 9 < 64 && BoardColor[Sq + 9] == ChessConstants.NEUTRAL) exposed++;
			//					}
			//				if( col < 7 ){
			if (Sq + 7 < 64 && BoardColor[Sq + 7] == ChessConstants.NEUTRAL) exposed++;
			//					}
			if (Sq + 8 < 64 && BoardColor[Sq + 8] == ChessConstants.NEUTRAL) exposed++;
			//				}
			if (col > 0)
			{
				if (BoardColor[Sq - 1] == ChessConstants.NEUTRAL) exposed++;
			}
			if (col < 7)
			{
				if (BoardColor[Sq + 1] == ChessConstants.NEUTRAL) exposed++;
			}

			Score = exposed * ChessConstants.EXPOSEDQK0;

			switch (Side)
			{
				case ChessConstants.WHITE:
					if (KingRow[ChessConstants.WHITE] == 0) Score += ChessConstants.KINGOFFROWBONUS;
					break;
				case ChessConstants.BLACK:
					if (KingRow[ChessConstants.WHITE] == 7) Score += ChessConstants.KINGOFFROWBONUS;
					break;
			}

			return (Score);

		}

		int _KingScore(int Sq, int Side)
		{
			int Score = 0;
			int xSide;

			xSide = Side ^ 1;

			/* End game */
			if (Material[Side] <= 1300)
			{
				Score += ChessData.KingEndingBonus[Sq];
			}
			/* Middle game */
			else
			{
				Score += ChessData.KingOpeningBonus[Sq];
				Score += _PreCastleKingBonus(Side);
			}

			return (Score);

		}

		int _PreCastleKingBonus(int Side)
		{

			if (Castled[Side]) return (ChessConstants.CASTLEBONUS);

			if (KingMoves[Side] != 0) return (ChessConstants.CASTLEPENALTY);

			return (ChessConstants.CASTLEAVAIL);

		}

		void _InitializeDistance()
		{
			int a, b, d, di;

			for (a = 0; a < 64; a++)
			{
				for (b = 0; b < 64; b++)
				{
					d = Math.Abs(((a & 7) - (b & 7)));
					di = Math.Abs(((a >> 3) - (b >> 3)));
					taxidata[a, b] = d + di;
					distdata[a, b] = (d > di ? d : di);
				}
			}

		}

		int m_nPly;

		int _search(int ply, int Side, int Alpha, int Beta)
		{
			int[] list = new int[300];
			int xSide;

			if (BailOut)
			{
				return (32001);
			}

			m_nPly = ply;

			#region DECLARE_LIST
			// Defines were here.
			int i = 0;
			int lcount = 0;
			int ssq = 0;
			int dsq = 0;
			int spc = 0;
			int dpc = 0;
			int scl = 0;
			int dcl = 0;
			int castle = 0;
			int Score = 0;
			int kf = 0;
			int kt = 0;
			int rf = 0;
			int rt = 0;
			int capture = 0;
			int sc = 0;
			int lastscore = 0;
			#endregion

			xSide = Side ^ 1;
			ply++;

			if ((ply & 1) != 0) Alpha = -31998;
			else Beta = 31998;

			if (ply == 1)
			{
				DoPly1Stuff(ref lastscore, ref lcount, ref list, ply);
			}
			else
			{
				lcount = _MakeMoveList(Side, ref list, ply);
			}

			// No moves.
			if (lcount == 0)
			{
				if ((ply & 1) != 0) return (-31999);
				else return (31999);
			}
			// Only one move.
			else if (ply == 1)
			{
				movesrc = list[0];
				movedst = list[1];
				if (lcount == 1)
				{
					return (0);
				}
			}

			for (i = 0; i < lcount; i++)
			{
				castle = capture = 0;

				ssq = list[i * 2];
				dsq = list[i * 2 + 1];

				if (BoardPiece[ssq] != ChessConstants.KING || (Math.Abs((Utils.FILE(ssq) - Utils.FILE(dsq))) <= 1))
				{
					MakeNonCastleMove(ref spc, ref scl, ref dpc, ref dcl, ssq, dsq, xSide, ref capture, Side);
				}
				else
				{
					MakeCastleMove(Side, ssq, dsq, ref kf, ref kt, ref rf, ref rt, ref castle);
				}

				// We have reached to maximum depth.
				if (ply >= SearchDepth)
				{

					// Calculate the material for each side.
					Material[ChessConstants.WHITE] = Material[ChessConstants.BLACK] = 0;
					for (int iii = 0; iii < 64; iii++)
					{
						if (BoardColor[iii] != ChessConstants.NEUTRAL) Material[BoardColor[iii]] += Materials[BoardPiece[iii]];
					}

					// Not actually sure how I arrived at the following two lines.
					if (Material[moveside] - Material[moveside ^ 1] < Alpha - 180) sc = Material[moveside] - Material[moveside ^ 1];
					else sc = _ScorePosition(moveside);
				}
				else
				{
					// Search one ply deeper.
					sc = _search(ply, Side ^ 1, Alpha, Beta);
				}

				// This is the bail out signal.
				if (sc == 32000)
				{
					return (32000);
				}

				Score = sc;

				if (ply == 1)
				{
					KeepTrackOfBestScores(Score, ssq, dsq);
				}

				if (castle == 0)
				{
					RewindNonCastleMove(ssq, dsq, spc, scl, dpc, dcl, Side);
				}
				else
				{
					RewindCastleMove(castle, ssq, Side);
				}

				if ((ply & 1) == 0)
				{
					/*
						If this ply will return the lowest score,
						the previous ply will return the highest score.

						That means any score I have that's lower than the highest
						score of the previous ply won't affect it's return score.

						If we find a score in this ply that's lower than the current
						high score of the previous ply, return with this low score
						since it will be rejected by the previous ply when it selects
						its return score.
					*/
					if (Beta > Score) Beta = Score;

					if (Beta < Alpha)
					{
						return (Beta);
					}
				}
				else
				{
					/*
						If this ply will return the highest score,
						the previous ply will return the lowest score.

						That means any score I have that's higher than the lowest
						score of the previous ply won't affect it's return score.

						If we find a score in this ply that's higher than the current
						low score of the previous ply, return with this high score
						since it will be rejected by the previous ply when it selects
						its return score.
					*/
					if (Alpha < Score)
					{
						Alpha = Score;
						if (ply == 1)
						{
							movesrc = list[i * 2];
							movedst = list[i * 2 + 1];
						}
					}

					if (Alpha > Beta && ply > 1)
					{
						return (Alpha);
					}
				}
			}

			if ((ply & 1) != 0) return (Alpha);
			else return (Beta);
		}

		void RewindNonCastleMove(int ssq, int dsq, int spc, int scl, int dpc, int dcl, int Side)
		{
			if (spc == ChessConstants.ROOK)
			{
				if (RookPos[Side, ChessConstants.LEFT] == dsq)
				{
					RookMoves[Side, ChessConstants.LEFT]--;
					if (RookMoves[Side, ChessConstants.LEFT] < 0) RookMoves[Side, ChessConstants.LEFT] = 0;
					RookPos[Side, ChessConstants.LEFT] = ssq;
				}
				else
				{
					RookMoves[Side, ChessConstants.RIGHT]--;
					if (RookMoves[Side, ChessConstants.RIGHT] < 0) RookMoves[Side, ChessConstants.RIGHT] = 0;
					RookPos[Side, ChessConstants.RIGHT] = ssq;
				}
			}
			else if (spc == ChessConstants.KING)
			{
				KingMoves[Side]--;
				KingSq[Side] = ssq;
			}

			BoardPiece[ssq] = spc;
			BoardColor[ssq] = scl;
			BoardPiece[dsq] = dpc;
			BoardColor[dsq] = dcl;
		}

		void KeepTrackOfBestScores(int Score, int ssq, int dsq)
		{
			int ii, kk;
			bool inserted = false;
			for (ii = 0; ii < BestCount; ii++)
			{
				if (Score > BestScores[ii])
				{
					for (kk = BestCount; kk > ii; kk--)
					{
						BestScores[kk] = BestScores[kk - 1];
						BestList[kk * 2] = BestList[(kk - 1) * 2];
						BestList[kk * 2 + 1] = BestList[(kk - 1) * 2 + 1];
					}
					BestScores[ii] = Score;
					BestList[ii * 2] = ssq;
					BestList[ii * 2 + 1] = dsq;
					inserted = true;
					ii = BestCount;
					if (BestCount < MaxBests) BestCount++;
				}
			}
			if (!inserted && BestCount < MaxBests)
			{
				BestScores[BestCount] = Score;
				BestList[BestCount * 2] = ssq;
				BestList[BestCount * 2 + 1] = dsq;
				BestCount++;
			}
		}

		void RewindCastleMove(int castle, int ssq, int Side)
		{
			KingMoves[Side]--;
			Castled[Side] = false;

			switch (castle)
			{
				case 1:
					KingSq[ChessConstants.WHITE] = ssq;
					BoardPiece[61] = BoardPiece[62] = 0;
					BoardColor[61] = BoardColor[62] = ChessConstants.NEUTRAL;
					BoardPiece[60] = ChessConstants.KING;
					BoardColor[60] = ChessConstants.WHITE;
					BoardPiece[63] = ChessConstants.ROOK;
					BoardColor[63] = ChessConstants.WHITE;
					RookPos[ChessConstants.WHITE, ChessConstants.RIGHT] = 63;
					RookMoves[ChessConstants.WHITE, ChessConstants.RIGHT] = 0;
					break;
				case 2:
					KingSq[ChessConstants.WHITE] = ssq;
					BoardPiece[58] = BoardPiece[59] = 0;
					BoardColor[58] = BoardColor[59] = ChessConstants.NEUTRAL;
					BoardPiece[60] = ChessConstants.KING;
					BoardColor[60] = ChessConstants.WHITE;
					BoardPiece[56] = ChessConstants.ROOK;
					BoardColor[56] = ChessConstants.WHITE;
					RookPos[ChessConstants.WHITE, ChessConstants.LEFT] = 56;
					RookMoves[ChessConstants.WHITE, ChessConstants.LEFT] = 0;
					break;
				case 3:
					KingSq[ChessConstants.BLACK] = ssq;
					BoardPiece[5] = BoardPiece[6] = 0;
					BoardColor[5] = BoardColor[6] = ChessConstants.NEUTRAL;
					BoardPiece[4] = ChessConstants.KING;
					BoardColor[4] = ChessConstants.BLACK;
					BoardPiece[7] = ChessConstants.ROOK;
					BoardColor[7] = ChessConstants.BLACK;
					RookPos[ChessConstants.BLACK, ChessConstants.RIGHT] = 7;
					RookMoves[ChessConstants.BLACK, ChessConstants.RIGHT] = 0;
					break;
				case 4:
					KingSq[ChessConstants.BLACK] = ssq;
					BoardPiece[2] = BoardPiece[3] = 0;
					BoardColor[2] = BoardColor[3] = ChessConstants.NEUTRAL;
					BoardPiece[4] = ChessConstants.KING;
					BoardColor[4] = ChessConstants.BLACK;
					BoardPiece[0] = ChessConstants.ROOK;
					BoardColor[0] = ChessConstants.BLACK;
					RookPos[ChessConstants.BLACK, ChessConstants.LEFT] = 0;
					RookMoves[ChessConstants.BLACK, ChessConstants.LEFT] = 0;
					break;
			}
		}

		void DoPly1Stuff(ref int lastscore, ref int lcount, ref int[] list, int ply)
		{
			lastscore = -31998;

			Material[ChessConstants.WHITE] = Material[ChessConstants.BLACK] = 0;

			for (int i = 0; i < 64; i++)
			{
				if (BoardColor[i] != ChessConstants.NEUTRAL) Material[BoardColor[i]] += Materials[BoardPiece[i]];
			}

			if (Material[ChessConstants.WHITE] < 1500 && Material[ChessConstants.BLACK] < 1500) EndGame = true;

			WantStalemate[ChessConstants.WHITE] = WantStalemate[ChessConstants.BLACK] = 0;

			if (Material[ChessConstants.WHITE] + Material[ChessConstants.BLACK] < 3700 && Math.Abs((Material[ChessConstants.WHITE] - Material[ChessConstants.BLACK])) > 500)
			{
				if (Material[ChessConstants.WHITE] > Material[ChessConstants.BLACK]) WantStalemate[ChessConstants.WHITE] = 1;
				else WantStalemate[ChessConstants.BLACK] = 1;
			}
			lcount = _MakeMoveList(Side, ref list, ply);
		}

		void MakeNonCastleMove(ref int spc, ref int scl, ref int dpc, ref int dcl, int ssq, int dsq, int xSide, ref int capture, int Side)
		{
			spc = BoardPiece[ssq];
			scl = BoardColor[ssq];
			dpc = BoardPiece[dsq];
			dcl = BoardColor[dsq];

			if (spc == ChessConstants.KING) KingSq[xSide] = dsq;

			if (dcl == xSide)
			{
				capture = dpc;
			}

			if (spc == ChessConstants.ROOK)
			{
				if (RookPos[Side, ChessConstants.LEFT] == ssq)
				{
					RookMoves[Side, ChessConstants.LEFT]++;
					RookPos[Side, ChessConstants.LEFT] = dsq;
				}
				else
				{
					RookMoves[Side, ChessConstants.RIGHT]++;
					RookPos[Side, ChessConstants.RIGHT] = dsq;
				}
			}
			else if (spc == ChessConstants.KING) KingMoves[Side]++;

			BoardPiece[dsq] = spc;
			BoardColor[dsq] = scl;
			BoardPiece[ssq] = 0;
			BoardColor[ssq] = ChessConstants.NEUTRAL;

			if (spc == ChessConstants.PAWN)
			{
				if (Side == ChessConstants.BLACK && (dsq >> 3) == 7) BoardPiece[dsq] = ChessConstants.QUEEN;
				else if (Side == ChessConstants.WHITE && (dsq >> 3) == 0) BoardPiece[dsq] = ChessConstants.QUEEN;
			}

		}

		void MakeCastleMove(int Side, int ssq, int dsq, ref int kf, ref int kt, ref int rf, ref int rt, ref int castle)
		{
			KingMoves[Side]++;
			Castled[Side] = true;

			switch (BoardColor[ssq])
			{
				case ChessConstants.WHITE:
					KingSq[ChessConstants.WHITE] = dsq;
					kf = 60;
					if (dsq == 62)
					{
						castle = 1;
						kt = 62;
						rf = 63;
						rt = 61;
						BoardPiece[60] = BoardPiece[63] = 0;
						BoardColor[60] = BoardColor[63] = ChessConstants.NEUTRAL;
						BoardPiece[62] = ChessConstants.KING;
						BoardColor[62] = ChessConstants.WHITE;
						BoardPiece[61] = ChessConstants.ROOK;
						BoardColor[61] = ChessConstants.WHITE;

						RookPos[ChessConstants.WHITE, ChessConstants.RIGHT] = 61;
						RookMoves[ChessConstants.WHITE, ChessConstants.RIGHT]++;
					}
					else
					{
						castle = 2;
						kt = 58;
						rf = 56;
						rt = 59;
						BoardPiece[60] = BoardPiece[56] = 0;
						BoardColor[60] = BoardColor[56] = ChessConstants.NEUTRAL;
						BoardPiece[58] = ChessConstants.KING;
						BoardColor[58] = ChessConstants.WHITE;
						BoardPiece[59] = ChessConstants.ROOK;
						BoardColor[59] = ChessConstants.WHITE;

						RookPos[ChessConstants.WHITE, ChessConstants.LEFT] = 59;
						RookMoves[ChessConstants.WHITE, ChessConstants.LEFT]++;
					}
					break;
				case ChessConstants.BLACK:
					KingSq[ChessConstants.BLACK] = dsq;
					kf = 4;
					if (dsq == 6)
					{
						castle = 3;
						kt = 6;
						rf = 7;
						rt = 5;
						BoardPiece[4] = BoardPiece[7] = 0;
						BoardColor[4] = BoardColor[7] = ChessConstants.NEUTRAL;
						BoardPiece[6] = ChessConstants.KING;
						BoardColor[6] = ChessConstants.BLACK;
						BoardPiece[5] = ChessConstants.ROOK;
						BoardColor[5] = ChessConstants.BLACK;

						RookPos[ChessConstants.BLACK, ChessConstants.RIGHT] = 5;
						RookMoves[ChessConstants.BLACK, ChessConstants.RIGHT]++;
					}
					else
					{
						castle = 4;
						kt = 2;
						rf = 0;
						rt = 3;
						BoardPiece[4] = BoardPiece[0] = 0;
						BoardColor[4] = BoardColor[0] = ChessConstants.NEUTRAL;
						BoardPiece[2] = ChessConstants.KING;
						BoardColor[2] = ChessConstants.BLACK;
						BoardPiece[3] = ChessConstants.ROOK;
						BoardColor[3] = ChessConstants.BLACK;

						RookPos[ChessConstants.BLACK, ChessConstants.LEFT] = 3;
						RookMoves[ChessConstants.BLACK, ChessConstants.LEFT]++;
					}
					break;
			}
		}


		int _MakeMoveList(int Side, ref int[] list, int ply)
		{
			int Sq, xSide;
			int TotalCount = 0;
			int[] TempList = new int[300];
			int Count;
			int i, j, k, tl;
			int start;
			int kfil, krnk, diff;
			bool chk;

			xSide = Side ^ 1;

			j = 0;
			kfil = Utils.FILE(KingSq[Side]);
			krnk = Utils.RANK(KingSq[Side]);
			chk = _InCheck(Side);

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					Count = _LegalMoves(Sq, ref list);
					diff = Sq - KingSq[Side];
					if (diff < 0) diff = -diff;
					if (chk ||
						(kfil == Utils.FILE(Sq) && _NothingBetween(Sq, KingSq[Side], 0) != 0) ||
						(krnk == Utils.RANK(Sq) && _NothingBetween(Sq, KingSq[Side], 1) != 0) ||
						((diff % 7) == 0 && _NothingBetween(Sq, KingSq[Side], 2) != 0) ||
						((diff % 9) == 0 && _NothingBetween(Sq, KingSq[Side], 3) != 0))
						Count = _RemoveKingInCheck(Count, Sq, ref list, Side);
					for (i = 0; i < Count; i++)
					{
						TempList[j++] = Sq;
						TempList[j++] = list[i];
					}
					TotalCount += Count;
				}
			}

			Count = 0;

			j = 1;
			for (i = 0; i < TotalCount; i++)
			{
				tl = TempList[j];
				if (BoardPiece[tl] == ChessConstants.QUEEN)
				{
					list[Count++] = TempList[j - 1];
					list[Count++] = tl;
				}
				j += 2;
			}
			j = 1;
			for (i = 0; i < TotalCount; i++)
			{
				tl = TempList[j];
				if (BoardPiece[tl] == ChessConstants.ROOK)
				{
					list[Count++] = TempList[j - 1];
					list[Count++] = tl;
				}
				j += 2;
			}
			j = 1;
			for (i = 0; i < TotalCount; i++)
			{
				tl = TempList[j];
				if (BoardPiece[tl] == ChessConstants.BISHOP)
				{
					list[Count++] = TempList[j - 1];
					list[Count++] = tl;
				}
				j += 2;
			}
			j = 1;
			for (i = 0; i < TotalCount; i++)
			{
				tl = TempList[j];
				if (BoardPiece[tl] == ChessConstants.KNIGHT)
				{
					list[Count++] = TempList[j - 1];
					list[Count++] = tl;
				}
				j += 2;
			}
			j = 1;
			for (i = 0; i < TotalCount; i++)
			{
				tl = TempList[j];
				if (BoardPiece[tl] == ChessConstants.PAWN)
				{
					list[Count++] = TempList[j - 1];
					list[Count++] = tl;
				}
				j += 2;
			}

			j = 1;
			for (i = 0; i < TotalCount; i++)
			{
				tl = TempList[j];
				if (BoardColor[tl] == ChessConstants.NEUTRAL)
				{
					list[Count++] = TempList[j - 1];
					list[Count++] = tl;
				}
				j += 2;
			}

			return (Count / 2);

		}

		int _AlmostRepetition()
		{

			if (CurrentMove < 12) return (0);

			if (MoveList[CurrentMove - 9].SrcSq != MoveList[CurrentMove - 5].SrcSq || MoveList[CurrentMove - 9].DestSq != MoveList[CurrentMove - 5].DestSq) return (0);
			if (MoveList[CurrentMove - 5].SrcSq != MoveList[CurrentMove - 1].SrcSq || MoveList[CurrentMove - 5].DestSq != MoveList[CurrentMove - 1].DestSq) return (0);

			if (MoveList[CurrentMove - 10].SrcSq != MoveList[CurrentMove - 6].SrcSq || MoveList[CurrentMove - 10].DestSq != MoveList[CurrentMove - 6].DestSq) return (0);
			if (MoveList[CurrentMove - 6].SrcSq != MoveList[CurrentMove - 2].SrcSq || MoveList[CurrentMove - 6].DestSq != MoveList[CurrentMove - 2].DestSq) return (0);

			if (MoveList[CurrentMove - 11].SrcSq != MoveList[CurrentMove - 7].SrcSq || MoveList[CurrentMove - 11].DestSq != MoveList[CurrentMove - 7].DestSq) return (0);
			if (MoveList[CurrentMove - 7].SrcSq != MoveList[CurrentMove - 3].SrcSq || MoveList[CurrentMove - 7].DestSq != MoveList[CurrentMove - 3].DestSq) return (0);

			if (MoveList[CurrentMove - 8].SrcSq != MoveList[CurrentMove - 4].SrcSq || MoveList[CurrentMove - 8].DestSq != MoveList[CurrentMove - 4].DestSq) return (0);

			RepetitionSrc = (short)MoveList[CurrentMove - 4].SrcSq;
			RepetitionDest = (short)MoveList[CurrentMove - 4].DestSq;

			return (1);

		}

		int _DrawByRepetition()
		{

			if (CurrentMove < 12) return (0);

			if (MoveList[CurrentMove - 9].SrcSq != MoveList[CurrentMove - 5].SrcSq || MoveList[CurrentMove - 9].DestSq != MoveList[CurrentMove - 5].DestSq) return (0);
			if (MoveList[CurrentMove - 5].SrcSq != MoveList[CurrentMove - 1].SrcSq || MoveList[CurrentMove - 5].DestSq != MoveList[CurrentMove - 1].DestSq) return (0);

			if (MoveList[CurrentMove - 10].SrcSq != MoveList[CurrentMove - 6].SrcSq || MoveList[CurrentMove - 10].DestSq != MoveList[CurrentMove - 6].DestSq) return (0);
			if (MoveList[CurrentMove - 6].SrcSq != MoveList[CurrentMove - 2].SrcSq || MoveList[CurrentMove - 6].DestSq != MoveList[CurrentMove - 2].DestSq) return (0);

			if (MoveList[CurrentMove - 11].SrcSq != MoveList[CurrentMove - 7].SrcSq || MoveList[CurrentMove - 11].DestSq != MoveList[CurrentMove - 7].DestSq) return (0);
			if (MoveList[CurrentMove - 7].SrcSq != MoveList[CurrentMove - 3].SrcSq || MoveList[CurrentMove - 7].DestSq != MoveList[CurrentMove - 3].DestSq) return (0);

			if (MoveList[CurrentMove - 12].SrcSq != MoveList[CurrentMove - 8].SrcSq || MoveList[CurrentMove - 12].DestSq != MoveList[CurrentMove - 8].DestSq) return (0);
			if (MoveList[CurrentMove - 8].SrcSq != MoveList[CurrentMove - 4].SrcSq || MoveList[CurrentMove - 8].DestSq != MoveList[CurrentMove - 4].DestSq) return (0);

			return (ChessConstants.MF_DRAW);

		}

		int _Stalemate(int Side)
		{
			int Sq;
			int[] List = new int[100];
			int Count;

			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == Side)
				{
					Count = _LegalMoves(Sq, ref List);
					Count = _RemoveKingInCheck(Count, Sq, ref List, Side);
					if (Count != 0) return (0);
				}
			}

			return (ChessConstants.MF_STALE);

		}

		int GetMoves(ref int[] MList)
		{
			int i, j;

			j = CurrentMove;
			if (j > 300) j = 300;

			for (i = 0; i < j; i++)
			{
				MList[i * 2] = MoveList[i].SrcSq;
				MList[i * 2 + 1] = MoveList[i].DestSq;
			}

			return (j);

		}

		int FindOpeningMoves(ref int[] Moves)
		{
			int[] MoveList = new int[500];
			int CurrentMove;
			int Total = 0;
			int i, j, match, alreadythere;
			int start = 0, end = ChessData.open.Length / 62;

			return (0);

			if (m_bEdited || mOpening == -2) return (0);

			CurrentMove = GetMoves(ref MoveList);
			if (CurrentMove > 22) return (0);

			if (mOpening != -1)
			{
				start = mOpening;
				end = mOpening + 1;
			}

			for (i = start; i < end; i++)
			{
				if (CurrentMove < ChessData.open[i * 62 + 1])
				{
					match = 1;
					for (j = 0; j < CurrentMove; j++)
					{
						if (MoveList[j * 2] != ChessData.open[i * 62 + 2 + j * 2] || MoveList[j * 2 + 1] != ChessData.open[i * 62 + 2 + j * 2 + 1])
						{
							match = 0;
							j = 10000;
						}
					}
					if (match != 0)
					{
						alreadythere = 0;
						for (j = 0; j < Total; j++)
						{
							if (ChessData.open[i * 62 + 2 + CurrentMove * 2] == Moves[j * 2] && ChessData.open[i * 62 + 2 + CurrentMove * 2 + 1] == Moves[j * 2 + 1])
							{
								alreadythere = 1;
								j = 10000;
							}
						}
						if (alreadythere == 0)
						{
							Moves[Total * 2] = ChessData.open[i * 62 + 2 + CurrentMove * 2];
							Moves[Total * 2 + 1] = ChessData.open[i * 62 + 2 + CurrentMove * 2 + 1];
							Total++;
						}
					}
				}
			}

			return (Total);

		}

		public void SetSearchDepth(int Depth)
		{

			SearchDepth = SDepth = Depth;

		}

		int SearchProgress(ref int Curr, ref int Max)
		{

			Curr = SaveList[1, 298];
			Max = SaveList[1, 299];

			if (SaveList[1, 298] == 0) return (0);

			return ((SaveList[1, 299] * 100) / SaveList[1, 298]);

		}

		bool GetPrincipleVariation(ref int Src, ref int Dst)
		{

			if (PVSrc == -1) return (false);

			if (Src != 0) Src = PVSrc;
			if (Dst != 0) Dst = PVDst;
			return (true);

		}

		int GetBestMovesList(ref int[] List, ref int[] Scores)
		{
			int i;

			for (i = 0; i < BestCount; i++)
			{
				List[i * 2] = BestList[i * 2];
				List[i * 2 + 1] = BestList[i * 2 + 1];
				Scores[i] = BestScores[i];
			}

			return (BestCount);

		}

		public ChessEngine Clone()
		{
			ChessEngine ret = new ChessEngine(); ;
			Clone(ref ret);
			return (ret);
		}

		public void Clone(ref ChessEngine engine)
		{
			int i, j;

			for (i = 0; i < 64; i++)
			{
				engine.BoardPiece[i] = BoardPiece[i];
				engine.BoardColor[i] = BoardColor[i];
			}

			engine.RepetitionSrc = RepetitionSrc;
			engine.RepetitionDest = RepetitionDest;
			engine.Promotion = Promotion;
			engine.EndGame = EndGame;
			engine.SearchDepth = SearchDepth;
			engine.SDepth = SDepth;
			engine.stime = stime;
			engine.etime = etime;
			engine.htime = htime;
			engine.sfirst = sfirst;
			engine.oldply = oldply;
			engine.GameOver = GameOver;
			engine.movesrc = movesrc;
			engine.movedst = movedst;
			engine.BestCount = BestCount;
			engine.MaxBests = MaxBests;
			engine.PVSrc = PVSrc;
			engine.PVDst = PVDst;
			engine.Side = Side;
			engine.Switched = Switched;
			engine.moveside = moveside;
			engine.CurrentMove = CurrentMove;
			engine.MaxMove = MaxMove;
			for (i = 0; i < ChessConstants.MAXMOVES; i++) engine.MoveList[i] = MoveList[i];
			for (i = 0; i < 2; i++)
			{
				engine.SkillLevel[i] = SkillLevel[i];
				engine.Castled[i] = Castled[i];
				engine.KingMoves[i] = KingMoves[i];
				engine.EnpassantPos[i] = EnpassantPos[i];
				engine.Material[i] = Material[i];
				engine.KingPos[i] = KingPos[i];
				engine.KingRow[i] = KingRow[i];
				engine.KingCol[i] = KingCol[i];
				engine.Developed[i] = Developed[i];
				engine.Develop[i] = Develop[i];
				engine.OpenFiles[i] = OpenFiles[i];
				engine.EightPawns[i] = EightPawns[i];
				engine.TwoBishopBonus[i] = TwoBishopBonus[i];
				engine.WantStalemate[i] = WantStalemate[i];
				engine.Pawns[i] = Pawns[i];
				engine.KingSq[i] = KingSq[i];
				for (j = 0; j < 2; j++)
				{
					engine.RookMoves[i, j] = RookMoves[i, j];
					engine.RookPos[i, j] = RookPos[i, j];
				}
				for (j = 0; j < 8; j++) engine.PawnsOnFile[i, j] = PawnsOnFile[i, j];
			}

			for (i = 0; i < 30; i++)
			{
				engine.BestList[i] = BestList[i];
				engine.MoveQueue[i] = MoveQueue[i];
			}

			for (i = 0; i < 15; i++)
			{
				engine.BestScores[i] = BestScores[i];
			}

			engine.LastSrcPc = LastSrcPc;
			engine.LastSrcCl = LastSrcCl;
			engine.LastDstPc = LastDstPc;
			engine.LastDstCl = LastDstCl;
			engine.LastSrc = LastSrc;
			engine.LastDst = LastDst;
			for (i = 0; i < 12; i++) engine.LastMoved[i] = LastMoved[i];

			for (i = 0; i < ChessConstants.MAXMOVES; i++)
			{
				engine.FlagList[i] = FlagList[i];
				engine.Beta[i] = Beta[i];
				engine.Capt[i] = Capt[i];
			}

		}

		bool IsGameOver()
		{

			return (GameOver);

		}

		public void UnsetGameOver()
		{
			GameOver = false;
		}

		void SetGameOver()
		{
			GameOver = true;
		}

		bool CanIDraw()
		{
			int i;
			int mine = 0, opponent = 0, diff, percent;

			if (_InCheckMate(Side)) return (false);

			for (i = 0; i < 64; i++)
			{
				if (BoardColor[i] == Side) mine += Materials[BoardPiece[i]];
				else if (BoardColor[i] == (Side ^ 1)) opponent += Materials[BoardPiece[i]];
			}

			if (mine >= 2200 && opponent >= 2200) return (false);
			diff = mine - opponent;
			if (diff < 0) return (false);

			percent = (diff * 100) / mine;
			if (percent < 55) return (false);

			return (true);

		}

		void GetDefaultBoard(ref int[] bd, ref int[] cl)
		{
			int i;

			for (i = 0; i < 64; i++)
			{
				bd[i] = ChessData.StartBoardPieces[i];
				cl[i] = ChessData.StartBoardColors[i];
			}

		}

		void LastMoveStuff(ref int SrcPc, ref int SrcCl, ref int DstPc, ref int DstCl, ref int Src, ref int Dst)
		{

			SrcPc = LastSrcPc;
			SrcCl = LastSrcCl;
			DstPc = LastDstPc;
			DstCl = LastDstCl;
			Src = LastSrc;
			Dst = LastDst;

			if (Switched)
			{
				Src = 63 - LastSrc;//( LastSrc & 7 ) | ( ( 7 - ( LastSrc >> 3 ) ) << 3 );
				Dst = 63 - LastDst;//( LastDst & 7 ) | ( ( 7 - ( LastDst >> 3 ) ) << 3 );
			}

		}

		int CanCastle()
		{
			int ret = 0;

			if (_CanCastle(Side, ChessConstants.LEFT)) ret = 1;
			if (_CanCastle(Side, ChessConstants.RIGHT)) ret |= 2;

			return (ret);

		}

		int _NothingBetween(int sq1, int sq2, int type)
		{
			int start, end, i;

			switch (type)
			{
				case 0:
					if (sq1 < sq2)
					{
						start = sq1;
						end = sq2;
					}
					else
					{
						start = sq2;
						end = sq1;
					}
					for (i = start + 8; i < end; i += 8)
					{
						if (BoardPiece[i] != 0) return (0);
					}
					break;
				case 1:
					if (sq1 < sq2)
					{
						start = sq1;
						end = sq2;
					}
					else
					{
						start = sq2;
						end = sq1;
					}
					for (i = start + 1; i < end; i++)
					{
						if (BoardPiece[i] != 0) return (0);
					}
					break;
				case 2:
					if (sq1 < sq2)
					{
						start = sq1;
						end = sq2;
					}
					else
					{
						start = sq2;
						end = sq1;
					}
					for (i = start + 7; i < end; i += 7)
					{
						if (BoardPiece[i] != 0) return (0);
					}
					break;
				case 3:
					if (sq1 < sq2)
					{
						start = sq1;
						end = sq2;
					}
					else
					{
						start = sq2;
						end = sq1;
					}
					for (i = start + 9; i < end; i += 9)
					{
						if (BoardPiece[i] != 0) return (0);
					}
					break;
			}

			return (1);
		}

		int InCheck(int flags)
		{

			uint tmp;
			tmp = (uint)ChessConstants.MF_CHECK;
			uint mask = (uint)0xffffffff;
			flags &= (int)(tmp ^ mask);
			tmp = (uint)ChessConstants.MF_CHECK;
			flags &= (int)(tmp ^ mask);
			if (_InCheck(Side))
			{
				flags |= ChessConstants.MF_CHECK;
				if (_InCheckMate(Side)) flags |= ChessConstants.MF_MATE;
			}

			return (flags);

		}

		int _DrawByLackOfForce()
		{
			int[] Knights = new int[2], Bishops = new int[2], Lack = new int[2], Rooks = new int[2];
			int i;

			Material[ChessConstants.WHITE] = Material[ChessConstants.BLACK] = Knights[ChessConstants.WHITE] = Knights[ChessConstants.BLACK] = Bishops[ChessConstants.WHITE] = Bishops[ChessConstants.BLACK] = Lack[ChessConstants.WHITE] = Lack[ChessConstants.BLACK] = Rooks[ChessConstants.WHITE] = Rooks[ChessConstants.BLACK] = 0;
			for (i = 0; i < 64; i++)
			{
				if (BoardColor[i] != ChessConstants.NEUTRAL)
				{
					Material[BoardColor[i]] += Materials[BoardPiece[i]];
					if (BoardPiece[i] == ChessConstants.KNIGHT) Knights[BoardColor[i]]++;
					if (BoardPiece[i] == ChessConstants.BISHOP) Bishops[BoardColor[i]]++;
					if (BoardPiece[i] == ChessConstants.ROOK) Rooks[BoardColor[i]]++;
				}
			}


			if (Material[ChessConstants.WHITE] == 0 && Material[ChessConstants.BLACK] == 0) return (ChessConstants.MF_LACKOFFORCE);

			for (i = 0; i < 2; i++)
			{
				if (Material[i] <= 300 && Bishops[i] == 1 && Knights[i] == 1) Lack[i] = 1;
				else if (Material[i] <= 600 && (Bishops[i] == 2 || Knights[i] == 2)) Lack[i] = 1;
				else if (Material[i] <= 500 && Rooks[i] == 1) Lack[i] = 1;
				else if (Material[i] <= 500 && Rooks[i] == 1 && (Bishops[i] == 1 || Knights[i] == 1)) Lack[i] = 1;
			}

			if (Lack[ChessConstants.WHITE] != 0 && Lack[ChessConstants.BLACK] != 0) return (ChessConstants.MF_LACKOFFORCE);

			return (0);

		}

		public void SetSide(int Sd)
		{

			Side = Sd;

#if CRAP
			CurrentMove = MaxMove = 0;
			GameOver = false;
			mOpening = -1;

			int[] RightLeft = new int[2];
			RightLeft[0] = RightLeft[1] = 0;

			KingMoves[ChessConstants.WHITE] = KingMoves[ChessConstants.BLACK] = 0;
			RookMoves[ChessConstants.WHITE,ChessConstants.LEFT] = RookMoves[ChessConstants.WHITE,ChessConstants.RIGHT] = RookMoves[ChessConstants.BLACK,ChessConstants.LEFT] = RookMoves[ChessConstants.BLACK,ChessConstants.RIGHT] = 0;
			RookPos[ChessConstants.WHITE,ChessConstants.LEFT] = 56;
			RookPos[ChessConstants.WHITE,ChessConstants.RIGHT] = 63;
			RookPos[ChessConstants.BLACK,ChessConstants.LEFT] = 0;
			RookPos[ChessConstants.BLACK,ChessConstants.RIGHT] = 7;

			EnpassantPos[ChessConstants.WHITE] = EnpassantPos[ChessConstants.BLACK] = -1;
			Castled[ChessConstants.WHITE] = Castled[ChessConstants.BLACK] = false;

		//	if( MaxMove == 0 ) return;

			int pc, cl;
			for( int i=0; i<64; i++ ){
				pc = BoardPiece[i];
				cl = BoardColor[i];
				if (pc == ChessConstants.ROOK && RightLeft[cl] < 2)
				{
					RookPos[cl,RightLeft[cl]] = i;
					RightLeft[cl]++;
					}
				else if (pc == ChessConstants.KING)
				{
					KingPos[cl] = i;
					if (cl == ChessConstants.BLACK && i != 4) KingMoves[ChessConstants.BLACK] = 100;
					else if (cl == ChessConstants.WHITE && i != 60) KingMoves[ChessConstants.WHITE] = 100;
					}
				}

			if (Utils.FILE(RookPos[ChessConstants.WHITE,ChessConstants.LEFT]) > Utils.FILE(RookPos[ChessConstants.WHITE, ChessConstants.RIGHT])) 
			{
				pc = RookPos[ChessConstants.WHITE,ChessConstants.LEFT];
				RookPos[ChessConstants.WHITE,ChessConstants.LEFT] = RookPos[ChessConstants.WHITE,ChessConstants.RIGHT];
				RookPos[ChessConstants.WHITE,ChessConstants.RIGHT] = pc;
			}
			if (Utils.FILE(RookPos[ChessConstants.BLACK,ChessConstants.LEFT]) > Utils.FILE(RookPos[ChessConstants.BLACK, ChessConstants.RIGHT])) 
			{
				pc = RookPos[ChessConstants.BLACK,ChessConstants.LEFT];
				RookPos[ChessConstants.BLACK,ChessConstants.LEFT] = RookPos[ChessConstants.BLACK,ChessConstants.RIGHT];
				RookPos[ChessConstants.BLACK,ChessConstants.RIGHT] = pc;
			}
			if (RookPos[ChessConstants.WHITE,ChessConstants.LEFT] != 56) RookMoves[ChessConstants.WHITE,ChessConstants.LEFT] = 100;
			if (RookPos[ChessConstants.WHITE,ChessConstants.RIGHT] != 63) RookMoves[ChessConstants.WHITE,ChessConstants.RIGHT] = 100;
			if (RookPos[ChessConstants.BLACK,ChessConstants.LEFT] != 0) RookMoves[ChessConstants.BLACK,ChessConstants.LEFT] = 100;
			if (RookPos[ChessConstants.BLACK,ChessConstants.RIGHT] != 7) RookMoves[ChessConstants.BLACK,ChessConstants.RIGHT] = 100;

			if (KingPos[ChessConstants.BLACK] == 6 && RookPos[ChessConstants.BLACK,ChessConstants.RIGHT] == 5) Castled[ChessConstants.BLACK] = true;
			if (KingPos[ChessConstants.BLACK] == 2 && RookPos[ChessConstants.BLACK,ChessConstants.LEFT] == 3) Castled[ChessConstants.BLACK] = true;
			if (KingPos[ChessConstants.WHITE] == 62 && RookPos[ChessConstants.WHITE,ChessConstants.RIGHT] == 61) Castled[ChessConstants.WHITE] = true;
			if (KingPos[ChessConstants.WHITE] == 59 && RookPos[ChessConstants.WHITE,ChessConstants.LEFT] == 58) Castled[ChessConstants.WHITE] = true;
#endif

		}

		int GetLastFlagSet(int ind)
		{
			int index = CurrentMove - 1;
			if (ind != -1) index = ind;


			return (FlagList[index]);

		}

		int _SetFlagSet(int index)
		{

			FlagList[index] = 0;

			if (index == 0) FlagList[0] = (ChessConstants.EF_WKINGWELLPROTECTED | ChessConstants.EF_BKINGWELLPROTECTED);

			int BetaDifference = 0;
			int Start = (short)index - 2;

			int Mat = 0;
			for (int k = 0; k < 64; k++)
			{
				if (BoardColor[k] != ChessConstants.NEUTRAL) Mat += Materials[BoardPiece[k]];
			}

			FlagList[index] |= _BadMove(index);
			FlagList[index] |= _GoodMove(index);

			int Sd = (short)(index & 1);

			if (Capt[index] == 0)
			{
				Start = (short)index - 1;
				int CaptureCount = 0;
				int[] Pnts = new int[2];
				Pnts[ChessConstants.WHITE] = Pnts[ChessConstants.BLACK] = 0;
				while (Start >= 0 && Capt[Start] != 0)
				{
					CaptureCount++;
					Pnts[Start & 1] += Capt[Start];
					Start--;
				}
				if (CaptureCount > 1)
				{
					if (Pnts[ChessConstants.WHITE] - Pnts[ChessConstants.BLACK] > 100) FlagList[index] |= (ChessConstants.EF_WGOODEXCHANGE | ChessConstants.EF_BBADEXCHANGE);
					else if (Pnts[ChessConstants.BLACK] - Pnts[ChessConstants.WHITE] > 100) FlagList[index] |= (ChessConstants.EF_BGOODEXCHANGE | ChessConstants.EF_WBADEXCHANGE);
				}
			}

			if ((FlagList[index] & ChessConstants.EF_BADMOVE) == 0 && (FlagList[index] & ChessConstants.EF_VERYBADMOVE) == 0) FlagList[index] |= _KingWellProtected(Sd, index);
			FlagList[index] |= _KingWellProtected(Sd ^ 1, index);
			if ((FlagList[index] & ChessConstants.EF_BADMOVE) == 0 && (FlagList[index] & ChessConstants.EF_VERYBADMOVE) == 0) FlagList[index] |= _MaterialAdvantage(Sd, index);
			FlagList[index] |= _MaterialAdvantage(Sd ^ 1, index);
			if ((FlagList[index] & ChessConstants.EF_BADMOVE) == 0 && (FlagList[index] & ChessConstants.EF_VERYBADMOVE) == 0) FlagList[index] |= _ControlCenter(Sd, index);
			FlagList[index] |= _ControlCenter(Sd ^ 1, index);

			if (Mat < 6000 && (FlagList[index] & ChessConstants.EF_WGAINEDCENTERCTRL) != 0) FlagList[index] ^= ChessConstants.EF_WGAINEDCENTERCTRL;
			if (Mat < 6000 && (FlagList[index] & ChessConstants.EF_BGAINEDCENTERCTRL) != 0) FlagList[index] ^= ChessConstants.EF_BGAINEDCENTERCTRL;

			return (FlagList[index]);

		}

		static int[] xy = {   -1, -1, 0, -1, 1, -1, 
								-1, 0,         1, 0,
								-1, 1,  0, 1,  1, 1 };

		int _KingWellProtected(int Sd, int index)
		{

			int i, KingFile, KingRow, KingSq = 0, Start;
			int YesFlag = ChessConstants.EF_WKINGWELLPROTECTED, NoFlag = ChessConstants.EF_WKINGNOTWELLPROTECTED;
			if (Sd == ChessConstants.BLACK)
			{
				YesFlag = ChessConstants.EF_BKINGWELLPROTECTED;
				NoFlag = ChessConstants.EF_BKINGNOTWELLPROTECTED;
			}
			bool KingWellProtected = false, KingNotWellProtected = false;
			int UnProtected = 0, row, file;
			for (i = 0; i < 64; i++)
			{
				if (BoardColor[i] == Sd && BoardPiece[i] == ChessConstants.KING) KingSq = i;
			}
			KingFile = Utils.FILE(KingSq);
			KingRow = Utils.RANK(KingSq);
			switch (Sd)
			{
				case ChessConstants.WHITE:
					for (i = 0; i < 8; i++)
					{
						file = KingFile + xy[i * 2];
						row = KingRow + xy[i * 2 + 1];
						if (file >= 0 && file <= 7 &&
							row >= 0 && row <= 7 &&
							file + row * 8 >= 0 && file + row * 8 <= 63 &&
							BoardColor[file + row * 8] != Sd) UnProtected++;
					}
					break;
				case ChessConstants.BLACK:
					for (i = 0; i < 8; i++)
					{
						file = KingFile + xy[i * 2];
						row = KingRow + xy[i * 2 + 1];
						if (file >= 0 && file <= 7 &&
							row >= 0 && row <= 7 &&
							file + row * 8 >= 0 && file + row * 8 <= 63 &&
							BoardColor[file + row * 8] != Sd) UnProtected++;
					}
					break;
			}
			if (index > 1 && UnProtected >= 5) KingNotWellProtected = true;
			else if (index > 1 && UnProtected <= 3) KingWellProtected = true;

			if (KingWellProtected)
			{
				Start = index - 1;
				while (Start >= 0)
				{
					if ((FlagList[Start] & YesFlag) != 0)
					{
						KingWellProtected = false;
						Start = -1;
					}
					else
					{
						if ((FlagList[Start] & NoFlag) != 0) Start = -1;
					}
					Start--;
				}
			}
			else if (KingNotWellProtected)
			{
				Start = index - 1;
				while (Start >= 0)
				{
					if ((FlagList[Start] & NoFlag) != 0)
					{
						KingNotWellProtected = false;
						Start = -1;
					}
					else if ((FlagList[Start] & YesFlag) != 0) Start = -1;
					Start--;
				}
			}
			if (KingWellProtected) return (YesFlag);
			else if (KingNotWellProtected) return (NoFlag);
			return (0);

		}

		int _MaterialAdvantage(int Sd, int index)
		{
			int i, Start;
			int[] Material = new int[2];
			int KingSq = 0, KingFile, KingRow;
			int YesFlag = ChessConstants.EF_WGAINEDMATERIALADV, NoFlag = ChessConstants.EF_WLOSTMATERIALADV;
			if (Sd == ChessConstants.BLACK)
			{
				YesFlag = ChessConstants.EF_BGAINEDMATERIALADV;
				NoFlag = ChessConstants.EF_BLOSTMATERIALADV;
			}
			Material[0] = Material[1] = 0;
			for (i = 0; i < 64; i++)
			{
				if (BoardColor[i] == Sd && BoardPiece[i] == ChessConstants.KING) KingSq = i;
				if (BoardColor[i] != ChessConstants.NEUTRAL) Material[BoardColor[i]] += Materials[BoardPiece[i]];
			}
			KingFile = Utils.FILE(KingSq);
			KingRow = Utils.RANK(KingSq);

			bool HaveMaterialAdvantage = false, GaveMaterialAdvantage = false;
			if (Material[Sd] - Material[Sd ^ 1] > 90) HaveMaterialAdvantage = true;
			else if (Material[Sd ^ 1] - Material[Sd] > 90) GaveMaterialAdvantage = true;
			if (HaveMaterialAdvantage)
			{
				Start = index - 1;
				while (Start >= 0)
				{
					if ((FlagList[Start] & YesFlag) != 0)
					{
						HaveMaterialAdvantage = false;
						Start = -1;
					}
					else if ((FlagList[Start] & NoFlag) != 0) Start = -1;
					Start--;
				}
			}
			else if (GaveMaterialAdvantage)
			{
				Start = index - 1;
				while (Start >= 0)
				{
					if ((FlagList[Start] & NoFlag) != 0)
					{
						GaveMaterialAdvantage = false;
						Start = -1;
					}
					else if ((FlagList[Start] & YesFlag) != 0) Start = -1;
					Start--;
				}
			}

			if (HaveMaterialAdvantage) return (YesFlag);
			else if (GaveMaterialAdvantage) return (NoFlag);
			return (0);

		}

		static int[] cnt = { 28, 29, 28 + 8, 29 + 8 };

		int _ControlCenter(int Sd, int index)
		{
			int YesFlag = ChessConstants.EF_WGAINEDCENTERCTRL, NoFlag = ChessConstants.EF_WLOSTCENTERCTRL;
			int i, j, Start;
			if (Sd == ChessConstants.BLACK)
			{
				YesFlag = ChessConstants.EF_BGAINEDCENTERCTRL;
				NoFlag = ChessConstants.EF_BLOSTCENTERCTRL;
			}
			bool ControlCenter = false, OpponentControlCenter = false;
			int[] List = new int[200];
			int Moves;
			int[] CenterControl = new int[2];
			CenterControl[0] = CenterControl[1] = 0;
			for (i = 0; i < 4; i++)
			{
				Moves = _GetCenterAttacks(cnt[i], ref List, Sd);
				for (j = 0; j < Moves; j++) CenterControl[BoardColor[List[j]]]++;
				if (BoardColor[cnt[i]] != ChessConstants.NEUTRAL) CenterControl[BoardColor[cnt[i]]]++;
			}
			if (Sd == ChessConstants.WHITE)
			{
				if (BoardColor[42] == ChessConstants.WHITE && BoardPiece[42] == ChessConstants.PAWN && BoardColor[36] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[43] == ChessConstants.WHITE && BoardPiece[43] == ChessConstants.PAWN && BoardColor[37] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[44] == ChessConstants.WHITE && BoardPiece[44] == ChessConstants.PAWN && BoardColor[36] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[45] == ChessConstants.WHITE && BoardPiece[45] == ChessConstants.PAWN && BoardColor[37] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[42 - 8] == ChessConstants.WHITE && BoardPiece[42 - 8] == ChessConstants.PAWN && BoardColor[36 - 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[43 - 8] == ChessConstants.WHITE && BoardPiece[43 - 8] == ChessConstants.PAWN && BoardColor[37 - 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[44 - 8] == ChessConstants.WHITE && BoardPiece[44 - 8] == ChessConstants.PAWN && BoardColor[36 - 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[45 - 8] == ChessConstants.WHITE && BoardPiece[45 - 8] == ChessConstants.PAWN && BoardColor[37 - 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
			}
			else
			{
				if (BoardColor[18] == ChessConstants.WHITE && BoardPiece[18] == ChessConstants.PAWN && BoardColor[28] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[19] == ChessConstants.WHITE && BoardPiece[19] == ChessConstants.PAWN && BoardColor[29] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[20] == ChessConstants.WHITE && BoardPiece[20] == ChessConstants.PAWN && BoardColor[28] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[21] == ChessConstants.WHITE && BoardPiece[21] == ChessConstants.PAWN && BoardColor[29] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[18 + 8] == ChessConstants.WHITE && BoardPiece[18 + 8] == ChessConstants.PAWN && BoardColor[28 + 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[19 + 8] == ChessConstants.WHITE && BoardPiece[19 + 8] == ChessConstants.PAWN && BoardColor[29 + 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[20 + 8] == ChessConstants.WHITE && BoardPiece[20 + 8] == ChessConstants.PAWN && BoardColor[28 + 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
				if (BoardColor[21 + 8] == ChessConstants.WHITE && BoardPiece[21 + 8] == ChessConstants.PAWN && BoardColor[29 + 8] == ChessConstants.NEUTRAL) CenterControl[ChessConstants.WHITE]++;
			}
			if (Sd == ChessConstants.WHITE && CenterControl[ChessConstants.WHITE] - CenterControl[ChessConstants.BLACK] >= 4) ControlCenter = true;
			else if (Sd == ChessConstants.BLACK && CenterControl[ChessConstants.BLACK] - CenterControl[ChessConstants.WHITE] >= 4) ControlCenter = true;
			else if (Sd == ChessConstants.WHITE && CenterControl[ChessConstants.BLACK] - CenterControl[ChessConstants.WHITE] >= 4) OpponentControlCenter = true;
			else if (Sd == ChessConstants.BLACK && CenterControl[ChessConstants.WHITE] - CenterControl[ChessConstants.BLACK] >= 4) OpponentControlCenter = true;
			if (ControlCenter)
			{
				Start = index - 1;
				while (Start >= 0)
				{
					if ((FlagList[Start] & YesFlag) != 0)
					{
						ControlCenter = false;
						Start = -1;
					}
					else if ((FlagList[Start] & NoFlag) != 0) Start = -1;
					Start--;
				}
			}
			else if (OpponentControlCenter)
			{
				Start = index - 1;
				while (Start >= 0)
				{
					if ((FlagList[Start] & NoFlag) != 0)
					{
						OpponentControlCenter = false;
						Start = -1;
					}
					else if ((FlagList[Start] & YesFlag) != 0) Start = -1;
					Start--;
				}
			}
			if (ControlCenter) return (YesFlag);
			else if (OpponentControlCenter) return (NoFlag);

			return (0);

		}

		int _GoodMove(int index)
		{
			int Sd = (short)(index & 1);
			int xSide = Sd ^ 1;
			int i, Count, Sq, UnderAttack;
			int[] List = new int[200];
			int SrcSq, DestSq;

			SrcSq = MoveList[index].SrcSq;
			DestSq = MoveList[index].DestSq;

			/*
				1. You took a piece without endangering a piece.
			*/
			if (index > 0 && Capt[index - 1] == 0 && Capt[index] != 0)
			{
				UnderAttack = 0;
				for (Sq = 0; Sq < 64; Sq++)
				{
					if (BoardColor[Sq] == xSide)
					{
						Count = _LegalMoves(Sq, ref List);
						Count = _RemoveKingInCheck(Count, Sq, ref List, xSide);
						for (i = 0; i < Count; i++)
						{
							if (List[i] == DestSq)
							{
								UnderAttack = 1;
								i = Count;
								Sq = 64;
							}
						}
					}
				}
				if (UnderAttack == 0 && Capt[index] > 100)
				{
					if (Capt[index] > 350) return (ChessConstants.EF_VERYGOODMOVE);
					return (ChessConstants.EF_GOODMOVE);
				}
			}

			/*
				2. You set up a favorable fork.
			*/


			/*
				3. You set up a favorable pin.
			*/


			/*
				4. You improved your positional score.
			*/
			int Start = index - 2;
			if (Start >= 0 && Beta[index] - Beta[Start] >= 150) return (ChessConstants.EF_GOODMOVE);

			return (0);

		}

		int _BadMove(int index)
		{

			int Sd = (short)(index & 1);
			int xSide = Sd ^ 1;
			int i, UnderAttack, WasUnderAttack, TheyWillBeUnderAttack, Count, Sq, MaxMaterial;
			int[] List = new int[200];
			int SrcSq, DestSq;

			SrcSq = MoveList[index].SrcSq;
			DestSq = MoveList[index].DestSq;

			/*
				1. You allowed a piece to be exposed to capture
				with no compensation.
			*/

			// Is the piece that was last moved under attack?
			UnderAttack = WasUnderAttack = TheyWillBeUnderAttack = MaxMaterial = 0;
			for (Sq = 0; Sq < 64; Sq++)
			{
				if (BoardColor[Sq] == xSide)
				{
					int OldSide = Side;
					Side = xSide;
					Count = _LegalMoves(Sq, ref List);
					Count = _RemoveKingInCheck(Count, Sq, ref List, xSide);
					Side = OldSide;
					for (i = 0; i < Count; i++)
					{
						if (List[i] == DestSq) UnderAttack = 1;
						if (List[i] == SrcSq) WasUnderAttack = 1;
					}
				}
				else if (BoardColor[Sq] == Sd)
				{
					int RememberColor = BoardColor[DestSq];
					BoardColor[DestSq] = xSide;
					int RememberPiece = BoardPiece[DestSq];
					BoardPiece[DestSq] = ChessConstants.PAWN;
					int OldSide = Side;
					Side = Sd;
					Count = _LegalMoves(Sq, ref List);
					if (BoardPiece[Sq] != ChessConstants.KING) Count = _RemoveKingInCheck(Count, Sq, ref List, Side);
					Side = OldSide;
					BoardColor[DestSq] = RememberColor;
					BoardPiece[DestSq] = RememberPiece;
					for (i = 0; i < Count; i++)
					{
						if (List[i] == DestSq) TheyWillBeUnderAttack = 1;
					}
				}
			}

			if (UnderAttack != 0 && WasUnderAttack == 0 && TheyWillBeUnderAttack == 0 && (Capt[index] == 0 || (Materials[BoardPiece[DestSq]] - Capt[index]) >= 100))
			{
				if (BoardPiece[DestSq] > 3) return (ChessConstants.EF_VERYBADMOVE);
				return (ChessConstants.EF_BADMOVE);
			}

			/*
				You've acheived a positional blunder.
			*/
			int Start = index - 2;
			if (Start >= 0 && Beta[Start] - Beta[index] >= 150) return (ChessConstants.EF_BADMOVE);

			return (0);

		}

		int distance(int a, int b)
		{
			return (distdata[a, b]);
		}

		int locn(int a, int b)
		{
			return (((a << 3) | b));
		}
	}

}
